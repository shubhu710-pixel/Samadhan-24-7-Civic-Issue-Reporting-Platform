const { PrismaClient } = require('@prisma/client');
const crypto = require('crypto');

const prisma = new PrismaClient();

async function checkDatabase() {
  try {
    console.log('Checking database...');
    
    // Check if users exist
    const users = await prisma.user.findMany({
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        emailVerified: true,
        password: true,
        createdAt: true,
        updatedAt: true
      }
    });
    
    console.log('Users found:', users.length);
    users.forEach(user => {
      console.log(`- ${user.email} (${user.role}): ${user.password}`);
      console.log(`  Email verified: ${user.emailVerified}`);
    });
    
    // Test password hash
    const testPassword = 'admin123';
    const testHash = crypto.createHash('sha256').update(testPassword).digest('hex');
    console.log(`\nTest password '${testPassword}' hashes to: ${testHash}`);
    
    // Check if any user matches
    const adminUser = users.find(u => u.email === 'admin@city.gov');
    if (adminUser) {
      console.log(`\nAdmin user password hash: ${adminUser.password}`);
      console.log(`Hashes match: ${adminUser.password === testHash}`);
    }
    
  } catch (error) {
    console.error('Error checking database:', error);
  } finally {
    await prisma.$disconnect();
  }
}

checkDatabase();