import { db } from '../src/lib/db'
import crypto from 'crypto'

async function main() {
  const issueTypes = [
    { name: 'Pothole', description: 'Damage to road surface', icon: '🕳️' },
    { name: 'Broken Streetlight', description: 'Streetlight not working', icon: '💡' },
    { name: 'Sanitation Issue', description: 'Garbage, waste, or cleanliness problems', icon: '🗑️' },
    { name: 'Road Damage', description: 'General road surface damage', icon: '🛣️' },
    { name: 'Traffic Signal', description: 'Traffic light or signal issues', icon: '🚦' },
    { name: 'Other', description: 'Other types of issues', icon: '📝' }
  ]

  const departments = [
    { name: 'Public Works', description: 'Handles public infrastructure issues', email: 'publicworks@city.gov' },
    { name: 'Sanitation Department', description: 'Handles waste management and cleanliness', email: 'sanitation@city.gov' },
    { name: 'Transportation Department', description: 'Handles traffic and transportation issues', email: 'transportation@city.gov' }
  ]

  const users = [
    {
      email: 'admin@city.gov',
      name: 'City Administrator',
      role: 'ADMIN',
      password: 'admin123',
      emailVerified: true
    },
    {
      email: 'staff@city.gov',
      name: 'City Staff',
      role: 'STAFF',
      password: 'staff123',
      emailVerified: true
    },
    {
      email: 'citizen@example.com',
      name: 'John Citizen',
      role: 'CITIZEN',
      password: 'citizen123',
      emailVerified: true
    }
  ]

  console.log('Seeding database...')

  // Create users
  for (const user of users) {
    const hashedPassword = crypto.createHash('sha256').update(user.password).digest('hex')
    
    await db.user.upsert({
      where: { email: user.email },
      update: {
        name: user.name,
        role: user.role,
        password: hashedPassword,
        emailVerified: user.emailVerified
      },
      create: {
        email: user.email,
        name: user.name,
        role: user.role,
        password: hashedPassword,
        emailVerified: user.emailVerified
      }
    })
  }

  // Create departments
  for (const dept of departments) {
    await db.department.upsert({
      where: { name: dept.name },
      update: {},
      create: dept
    })
  }

  // Create issue types
  for (const issueType of issueTypes) {
    await db.issueType.upsert({
      where: { name: issueType.name },
      update: {},
      create: issueType
    })
  }

  console.log('Database seeded successfully!')
  console.log('Default users created:')
  console.log('Admin: admin@city.gov / admin123')
  console.log('Staff: staff@city.gov / staff123')
  console.log('Citizen: citizen@example.com / citizen123')
}

main()
  .catch((e) => {
    console.error(e)
    process.exit(1)
  })
  .finally(async () => {
    await db.$disconnect()
  })