import ZAI from 'z-ai-web-dev-sdk'

interface EmailOptions {
  to: string
  subject: string
  body: string
  isHTML?: boolean
}

export class EmailService {
  private static zai: any = null

  /**
   * Initialize the Z-AI SDK
   */
  private static async initialize() {
    if (!this.zai) {
      try {
        this.zai = await ZAI.create()
      } catch (error) {
        console.error('Failed to initialize Z-AI SDK:', error)
        throw new Error('Email service initialization failed')
      }
    }
  }

  /**
   * Send OTP email
   */
  static async sendOTP(email: string, otp: string): Promise<boolean> {
    try {
      await this.initialize()

      const subject = 'Verify Your Email - CityFix'
      const body = this.generateOTPEmailBody(otp)

      return await this.sendEmail({
        to: email,
        subject,
        body,
        isHTML: true
      })
    } catch (error) {
      console.error('Error sending OTP email:', error)
      return false
    }
  }

  /**
   * Send welcome email
   */
  static async sendWelcomeEmail(email: string, name: string): Promise<boolean> {
    try {
      await this.initialize()

      const subject = 'Welcome to CityFix!'
      const body = this.generateWelcomeEmailBody(name)

      return await this.sendEmail({
        to: email,
        subject,
        body,
        isHTML: true
      })
    } catch (error) {
      console.error('Error sending welcome email:', error)
      return false
    }
  }

  /**
   * Send issue status update email
   */
  static async sendIssueUpdateEmail(
    email: string, 
    issueTitle: string, 
    status: string, 
    userName?: string
  ): Promise<boolean> {
    try {
      await this.initialize()

      const subject = `Issue Update: ${issueTitle}`
      const body = this.generateIssueUpdateEmailBody(issueTitle, status, userName)

      return await this.sendEmail({
        to: email,
        subject,
        body,
        isHTML: true
      })
    } catch (error) {
      console.error('Error sending issue update email:', error)
      return false
    }
  }

  /**
   * Generic email sending method
   */
  private static async sendEmail(options: EmailOptions): Promise<boolean> {
    try {
      await this.initialize()

      // Try to use Z-AI SDK to send emails
      try {
        const result = await this.zai.functions.invoke("send_email", {
          to: options.to,
          subject: options.subject,
          body: options.body,
          is_html: options.isHTML || false
        })

        console.log(`Email sent to: ${options.to}`)
        console.log(`Subject: ${options.subject}`)
        
        return true
      } catch (sdkError) {
        console.warn('Z-AI SDK email sending failed, using fallback:', sdkError.message)
        
        // Fallback: Log email details for development
        console.log('=== EMAIL FALLBACK (Development Mode) ===')
        console.log(`To: ${options.to}`)
        console.log(`Subject: ${options.subject}`)
        console.log(`Body: ${options.body.substring(0, 200)}...`)
        console.log('==========================================')
        
        // In development, we'll consider this a success
        // In production, you might want to return false here
        return process.env.NODE_ENV === 'development'
      }
    } catch (error) {
      console.error('Error sending email:', error)
      return false
    }
  }

  /**
   * Generate OTP email body
   */
  private static generateOTPEmailBody(otp: string): string {
    const formattedOTP = otp.split('').join(' ')
    
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Email Verification</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .otp { font-size: 32px; font-weight: bold; text-align: center; 
                  background: #f0f0f0; padding: 20px; border-radius: 8px; 
                  letter-spacing: 8px; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; 
                   padding-top: 20px; border-top: 1px solid #eee; 
                   font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>CityFix</h1>
            <h2>Email Verification</h2>
          </div>
          
          <p>Hello,</p>
          <p>Thank you for registering with CityFix! To complete your registration, please use the following One-Time Password (OTP) to verify your email address:</p>
          
          <div class="otp">${formattedOTP}</div>
          
          <p><strong>Important:</strong></p>
          <ul>
            <li>This OTP will expire in 3 minutes</li>
            <li>Please do not share this OTP with anyone</li>
            <li>If you didn't request this OTP, please ignore this email</li>
          </ul>
          
          <p>If you have any questions or didn't request this verification, please contact our support team.</p>
          
          <div class="footer">
            <p>© 2024 CityFix. All rights reserved.</p>
            <p>This is an automated message, please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `
  }

  /**
   * Generate welcome email body
   */
  private static generateWelcomeEmailBody(name: string): string {
    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Welcome to CityFix</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .welcome { background: #f0f8ff; padding: 20px; border-radius: 8px; 
                     text-align: center; margin: 20px 0; }
          .footer { text-align: center; margin-top: 30px; 
                   padding-top: 20px; border-top: 1px solid #eee; 
                   font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏙️ CityFix</h1>
            <h2>Welcome aboard, ${name}!</h2>
          </div>
          
          <div class="welcome">
            <h3>🎉 Your account has been successfully created!</h3>
            <p>You're now ready to start reporting issues and helping improve our community.</p>
          </div>
          
          <p><strong>What you can do with CityFix:</strong></p>
          <ul>
            <li>📍 Report local issues with GPS location</li>
            <li>📷 Upload photos of problems</li>
            <li>📊 Track issue status in real-time</li>
            <li>🔔 Receive notifications about updates</li>
            <li>🗺️ View issues on an interactive map</li>
          </ul>
          
          <p><strong>Getting Started:</strong></p>
          <ol>
            <li>Click on "Report Issue" to report your first local problem</li>
            <li>Use GPS to automatically set your location</li>
            <li>Add photos and detailed descriptions</li>
            <li>Track the progress of your reports</li>
          </ol>
          
          <p>If you have any questions or need help, feel free to reach out to our support team.</p>
          
          <div class="footer">
            <p>© 2024 CityFix. All rights reserved.</p>
            <p>This is an automated message, please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `
  }

  /**
   * Generate issue update email body
   */
  private static generateIssueUpdateEmailBody(
    issueTitle: string, 
    status: string, 
    userName?: string
  ): string {
    const statusMessages = {
      'REPORTED': 'Your issue has been received and is being reviewed.',
      'IN_PROGRESS': 'Work has begun on resolving your issue!',
      'RESOLVED': 'Great news! Your issue has been resolved.',
      'REJECTED': 'Your issue could not be addressed at this time.'
    }

    const statusIcons = {
      'REPORTED': '📝',
      'IN_PROGRESS': '🔧',
      'RESOLVED': '✅',
      'REJECTED': '❌'
    }

    return `
      <!DOCTYPE html>
      <html>
      <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <title>Issue Update</title>
        <style>
          body { font-family: Arial, sans-serif; line-height: 1.6; color: #333; }
          .container { max-width: 600px; margin: 0 auto; padding: 20px; }
          .header { text-align: center; margin-bottom: 30px; }
          .status-update { background: #f8f9fa; padding: 20px; border-radius: 8px; 
                          margin: 20px 0; border-left: 4px solid #007bff; }
          .footer { text-align: center; margin-top: 30px; 
                   padding-top: 20px; border-top: 1px solid #eee; 
                   font-size: 12px; color: #666; }
        </style>
      </head>
      <body>
        <div class="container">
          <div class="header">
            <h1>🏙️ CityFix</h1>
            <h2>Issue Update</h2>
          </div>
          
          <p>Hello ${userName || 'there'},</p>
          <p>There's an update on the issue you reported:</p>
          
          <div class="status-update">
            <h3>${statusIcons[status as keyof typeof statusIcons] || '📝'} ${issueTitle}</h3>
            <p><strong>Status:</strong> ${status.replace('_', ' ')}</p>
            <p>${statusMessages[status as keyof typeof statusMessages] || 'Your issue status has been updated.'}</p>
          </div>
          
          <p>You can view more details and track the progress of your issue by logging into your CityFix account.</p>
          
          <p>Thank you for helping improve our community!</p>
          
          <div class="footer">
            <p>© 2024 CityFix. All rights reserved.</p>
            <p>This is an automated message, please do not reply to this email.</p>
          </div>
        </div>
      </body>
      </html>
    `
  }
}