import crypto from 'crypto'

export interface OTPData {
  email: string
  otp: string
  expiresAt: Date
  attempts: number
  verified: boolean
}

export class OTPService {
  private static readonly OTP_LENGTH = 6
  private static readonly OTP_EXPIRY_MINUTES = 3
  private static readonly MAX_ATTEMPTS = 3

  /**
   * Get current time in UTC
   */
  private static getCurrentTime(): Date {
    return new Date()
  }

  /**
   * Create expiration time (3 minutes from now in UTC)
   */
  private static createExpirationTime(): Date {
    const now = this.getCurrentTime()
    const expirationTime = new Date(now.getTime() + this.OTP_EXPIRY_MINUTES * 60 * 1000)
    
    // Debug logging - remove in production
    if (process.env.NODE_ENV === 'development') {
      console.log('OTP Debug - Current Time:', now.toISOString())
      console.log('OTP Debug - Expiration Time:', expirationTime.toISOString())
      console.log('OTP Debug - Minutes until expiration:', this.OTP_EXPIRY_MINUTES)
    }
    
    return expirationTime
  }

  /**
   * Generate a random OTP
   */
  static generateOTP(): string {
    const digits = '0123456789'
    let otp = ''
    for (let i = 0; i < this.OTP_LENGTH; i++) {
      otp += digits[Math.floor(Math.random() * digits.length)]
    }
    return otp
  }

  /**
   * Create OTP data with expiration
   */
  static createOTPData(email: string): OTPData {
    return {
      email,
      otp: this.generateOTP(),
      expiresAt: this.createExpirationTime(),
      attempts: 0,
      verified: false
    }
  }

  /**
   * Check if OTP is expired
   */
  static isExpired(otpData: OTPData): boolean {
    const currentTime = this.getCurrentTime()
    const isExpired = currentTime > otpData.expiresAt
    
    // Debug logging - remove in production
    if (process.env.NODE_ENV === 'development') {
      console.log('OTP Debug - Current Time:', currentTime.toISOString())
      console.log('OTP Debug - Expiration Time:', otpData.expiresAt.toISOString())
      console.log('OTP Debug - Is Expired:', isExpired)
      console.log('OTP Debug - Time Difference (ms):', currentTime.getTime() - otpData.expiresAt.getTime())
    }
    
    return isExpired
  }

  /**
   * Check if OTP attempts are exceeded
   */
  static isAttemptsExceeded(otpData: OTPData): boolean {
    return otpData.attempts >= this.MAX_ATTEMPTS
  }

  /**
   * Verify OTP
   */
  static verifyOTP(otpData: OTPData, providedOTP: string): boolean {
    if (this.isExpired(otpData)) {
      return false
    }

    if (this.isAttemptsExceeded(otpData)) {
      return false
    }

    otpData.attempts += 1

    if (otpData.otp === providedOTP) {
      otpData.verified = true
      return true
    }

    return false
  }

  /**
   * Get remaining time in minutes
   */
  static getRemainingTime(otpData: OTPData): number {
    const remaining = otpData.expiresAt.getTime() - this.getCurrentTime().getTime()
    return Math.max(0, Math.ceil(remaining / (60 * 1000)))
  }

  /**
   * Get remaining time in seconds for precise frontend timing
   */
  static getRemainingTimeInSeconds(otpData: OTPData): number {
    const remaining = otpData.expiresAt.getTime() - this.getCurrentTime().getTime()
    return Math.max(0, Math.ceil(remaining / 1000))
  }

  /**
   * Format OTP for display (with spaces for readability)
   */
  static formatOTP(otp: string): string {
    return otp.split('').join(' ')
  }

  /**
   * Validate email format
   */
  static isValidEmail(email: string): boolean {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/
    return emailRegex.test(email)
  }

  /**
   * Hash OTP for secure storage
   */
  static hashOTP(otp: string): string {
    return crypto.createHash('sha256').update(otp).digest('hex')
  }

  /**
   * Verify hashed OTP
   */
  static verifyHashedOTP(hashedOTP: string, providedOTP: string): boolean {
    const hashedProvided = this.hashOTP(providedOTP)
    return hashedOTP === hashedProvided
  }
}