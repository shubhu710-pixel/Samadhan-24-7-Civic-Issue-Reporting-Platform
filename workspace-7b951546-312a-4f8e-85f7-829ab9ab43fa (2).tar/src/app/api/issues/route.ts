import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    const { searchParams } = new URL(request.url)
    const status = searchParams.get('status')
    const priority = searchParams.get('priority')
    const type = searchParams.get('type')
    const page = parseInt(searchParams.get('page') || '1')
    const limit = parseInt(searchParams.get('limit') || '10')
    const offset = (page - 1) * limit

    const whereClause: any = {}
    
    if (status) {
      whereClause.status = status
    }
    
    if (priority) {
      whereClause.priority = priority
    }
    
    if (type) {
      whereClause.type = {
        name: type
      }
    }

    const [issues, total] = await Promise.all([
      db.issue.findMany({
        where: whereClause,
        include: {
          reporter: {
            select: {
              id: true,
              name: true,
              email: true
            }
          },
          assignedTo: {
            select: {
              id: true,
              name: true,
              email: true
            }
          },
          type: true,
          department: true
        },
        orderBy: {
          createdAt: 'desc'
        },
        skip: offset,
        take: limit
      }),
      db.issue.count({
        where: whereClause
      })
    ])

    return NextResponse.json({
      issues,
      pagination: {
        page,
        limit,
        total,
        pages: Math.ceil(total / limit)
      }
    })
  } catch (error) {
    console.error('Error fetching issues:', error)
    return NextResponse.json(
      { error: 'Failed to fetch issues' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { title, description, location, latitude, longitude, issueTypeId, priority, reporterId, imageUrl } = body

    console.log('Issues API Debug - Received body:', body)
    console.log('Issues API Debug - issueTypeId:', issueTypeId, 'type:', typeof issueTypeId)

    // Validate required fields
    if (!title || !description || !location || !issueTypeId || !reporterId) {
      console.log('Issues API Debug - Missing required fields:', {
        title: !!title,
        description: !!description,
        location: !!location,
        issueTypeId: !!issueTypeId,
        reporterId: !!reporterId
      })
      return NextResponse.json(
        { error: 'Missing required fields' },
        { status: 400 }
      )
    }

    // Get the issue type to determine the department
    const issueType = await db.issueType.findUnique({
      where: { id: issueTypeId }
    })

    console.log('Issues API Debug - Found issue type:', issueType)

    if (!issueType) {
      console.log('Issues API Debug - Issue type not found for ID:', issueTypeId)
      
      // List all available issue types for debugging
      const allIssueTypes = await db.issueType.findMany()
      console.log('Issues API Debug - All available issue types:', allIssueTypes)
      
      return NextResponse.json(
        { error: 'Invalid issue type' },
        { status: 400 }
      )
    }

    // For demo purposes, assign to a default department
    // In a real app, you'd have logic to determine the correct department
    let department = await db.department.findFirst()
    if (!department) {
      // Create a default department if none exists
      department = await db.department.create({
        data: {
          name: 'Public Works',
          description: 'Handles public infrastructure issues',
          email: 'publicworks@city.gov'
        }
      })
    }

    const issue = await db.issue.create({
      data: {
        title,
        description,
        location,
        latitude,
        longitude,
        typeId: issueTypeId,
        departmentId: department.id,
        priority: priority || 'MEDIUM',
        reporterId,
        imageUrl: imageUrl || null
      },
      include: {
        reporter: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        type: true,
        department: true
      }
    })

    // Create notification for the reporter
    await db.notification.create({
      data: {
        title: 'Issue Reported',
        message: `Your issue "${title}" has been reported successfully.`,
        type: 'ISSUE_REPORTED',
        userId: reporterId,
        issueId: issue.id
      }
    })

    return NextResponse.json(issue, { status: 201 })
  } catch (error) {
    console.error('Error creating issue:', error)
    return NextResponse.json(
      { error: 'Failed to create issue' },
      { status: 500 }
    )
  }
}