import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { OTPService } from '@/lib/otp'
import { EmailService } from '@/lib/email'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const { email, name, password, role = 'CITIZEN' } = await request.json()

    if (!email || !password || !OTPService.isValidEmail(email)) {
      return NextResponse.json(
        { error: 'Valid email and password are required' },
        { status: 400 }
      )
    }

    // Check if user already exists
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      return NextResponse.json(
        { error: 'User already exists' },
        { status: 400 }
      )
    }

    // Check if email is verified via OTP
    // We only check if it's verified, not if it's expired, since verified OTPs should remain valid
    const verifiedOTP = await db.oTP.findFirst({
      where: {
        email,
        verified: true
      }
    })

    if (!verifiedOTP) {
      return NextResponse.json(
        { error: 'Email not verified. Please verify your email first.' },
        { status: 400 }
      )
    }

    console.log('Registration Debug - Found verified OTP:', {
      email: verifiedOTP.email,
      verified: verifiedOTP.verified,
      expiresAt: verifiedOTP.expiresAt,
      currentTime: new Date(),
      isExpired: new Date() > verifiedOTP.expiresAt
    })

    // Hash password (in a real app, use bcrypt or similar)
    const hashedPassword = await hashPassword(password)

    // Create user
    const user = await db.user.create({
      data: {
        email,
        name,
        password: hashedPassword,
        role: role.toUpperCase(),
        emailVerified: true
      },
      select: {
        id: true,
        email: true,
        name: true,
        role: true,
        emailVerified: true,
        createdAt: true
      }
    })

    // Clean up verified OTP
    await db.oTP.deleteMany({
      where: {
        email,
        verified: true
      }
    })

    // Send welcome email
    await EmailService.sendWelcomeEmail(email, name || 'User')

    return NextResponse.json({
      message: 'User registered successfully',
      user
    })

  } catch (error) {
    console.error('Error registering user:', error)
    return NextResponse.json(
      { error: 'Failed to register user' },
      { status: 500 }
    )
  }
}

// Helper function to hash password (simplified for demo)
async function hashPassword(password: string): Promise<string> {
  // In a real application, use bcrypt:
  // import bcrypt from 'bcrypt'
  // const saltRounds = 10
  // return await bcrypt.hash(password, saltRounds)
  
  // For demo purposes, we'll use a simple hash with Node.js crypto
  return crypto.createHash('sha256').update(password).digest('hex')
}