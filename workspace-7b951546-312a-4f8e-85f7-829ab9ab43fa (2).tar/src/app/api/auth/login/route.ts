import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import crypto from 'crypto'

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    if (!email || !password) {
      return NextResponse.json(
        { error: 'Email and password are required' },
        { status: 400 }
      )
    }

    // Find user
    const user = await db.user.findUnique({
      where: { email }
    })

    if (!user) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    // Check if email is verified
    // if (!user.emailVerified) {
    //   return NextResponse.json(
    //     { error: 'Email not verified. Please verify your email first.' },
    //     { status: 401 }
    //   )
    // }

    // Verify password
    const isValidPassword = await verifyPassword(password, user.password)

    if (!isValidPassword) {
      return NextResponse.json(
        { error: 'Invalid credentials' },
        { status: 401 }
      )
    }

    // Return user data (in a real app, you would generate a JWT token here)
    return NextResponse.json({
      message: 'Login successful',
      user: {
        id: user.id,
        email: user.email,
        name: user.name,
        role: user.role,
        emailVerified: user.emailVerified
      }
    })

  } catch (error) {
    console.error('Error logging in:', error)
    return NextResponse.json(
      { error: 'Failed to login' },
      { status: 500 }
    )
  }
}

// Helper function to verify password (simplified for demo)
async function verifyPassword(password: string, hashedPassword: string): Promise<boolean> {
  // In a real application, use bcrypt:
  // import bcrypt from 'bcrypt'
  // return await bcrypt.compare(password, hashedPassword)
  
  // For demo purposes, we'll use a simple hash comparison
  const inputHash = crypto.createHash('sha256').update(password).digest('hex')
  return inputHash === hashedPassword
}