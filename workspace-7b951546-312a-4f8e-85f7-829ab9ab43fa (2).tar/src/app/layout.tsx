import type { Metadata } from "next";
import { Geist, Geist_Mono } from "next/font/google";
import "./globals.css";
import { Toaster } from "@/components/ui/toaster";
import { AuthProvider } from "@/contexts/AuthContext";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

const geistMono = Geist_Mono({
  variable: "--font-geist-mono",
  subsets: ["latin"],
});

export const metadata: Metadata = {
  title: "CityFix - Urban Issue Reporting & Resolution",
  description: "Report local issues like potholes, broken streetlights, and sanitation problems. Help make our city cleaner and safer for everyone.",
  keywords: ["CityFix", "urban issues", "reporting", "civic engagement", "smart cities", "infrastructure"],
  authors: [{ name: "CityFix Team" }],
  openGraph: {
    title: "CityFix - Urban Issue Reporting",
    description: "Report and resolve local issues in your community",
    url: "https://cityfix.example.com",
    siteName: "CityFix",
    type: "website",
  },
  twitter: {
    card: "summary_large_image",
    title: "CityFix - Urban Issue Reporting",
    description: "Report and resolve local issues in your community",
  },
};

export default function RootLayout({
  children,
}: Readonly<{
  children: React.ReactNode;
}>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body
        className={`${geistSans.variable} ${geistMono.variable} antialiased bg-background text-foreground`}
      >
        <AuthProvider>
          {children}
          <Toaster />
        </AuthProvider>
      </body>
    </html>
  );
}
