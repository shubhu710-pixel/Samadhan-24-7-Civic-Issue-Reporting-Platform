"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Bell, CheckCircle, AlertTriangle, Info, Clock, X } from "lucide-react"

interface Notification {
  id: string
  title: string
  message: string
  type: string
  read: boolean
  createdAt: string
  issue?: {
    id: string
    title: string
    status: string
    priority: string
  }
}

interface NotificationSystemProps {
  userId: string
}

export default function NotificationSystem({ userId }: NotificationSystemProps) {
  const [notifications, setNotifications] = useState<Notification[]>([])
  const [unreadCount, setUnreadCount] = useState(0)
  const [isOpen, setIsOpen] = useState(false)
  const [loading, setLoading] = useState(true)

  // Mock notifications for demonstration
  const mockNotifications: Notification[] = [
    {
      id: "1",
      title: "Issue Reported",
      message: "Your issue 'Large pothole on Main Street' has been reported successfully.",
      type: "ISSUE_REPORTED",
      read: false,
      createdAt: "2024-01-15T10:30:00Z",
      issue: {
        id: "1",
        title: "Large pothole on Main Street",
        status: "REPORTED",
        priority: "HIGH"
      }
    },
    {
      id: "2",
      title: "Issue In Progress",
      message: "Your issue 'Broken streetlight near park' is now being addressed.",
      type: "ISSUE_IN_PROGRESS",
      read: false,
      createdAt: "2024-01-14T15:45:00Z",
      issue: {
        id: "2",
        title: "Broken streetlight near park",
        status: "IN_PROGRESS",
        priority: "MEDIUM"
      }
    },
    {
      id: "3",
      title: "Issue Resolved",
      message: "Your issue 'Overflowing garbage bin' has been resolved.",
      type: "ISSUE_RESOLVED",
      read: true,
      createdAt: "2024-01-13T09:15:00Z",
      issue: {
        id: "3",
        title: "Overflowing garbage bin",
        status: "RESOLVED",
        priority: "LOW"
      }
    }
  ]

  useEffect(() => {
    // Simulate API call to fetch notifications
    setTimeout(() => {
      setNotifications(mockNotifications)
      setUnreadCount(mockNotifications.filter(n => !n.read).length)
      setLoading(false)
    }, 1000)
  }, [userId])

  const getNotificationIcon = (type: string) => {
    switch (type) {
      case "ISSUE_REPORTED":
        return <Info className="h-4 w-4 text-blue-500" />
      case "ISSUE_ASSIGNED":
        return <Clock className="h-4 w-4 text-yellow-500" />
      case "ISSUE_IN_PROGRESS":
        return <Clock className="h-4 w-4 text-blue-500" />
      case "ISSUE_RESOLVED":
        return <CheckCircle className="h-4 w-4 text-green-500" />
      case "ISSUE_REJECTED":
        return <AlertTriangle className="h-4 w-4 text-red-500" />
      default:
        return <Bell className="h-4 w-4 text-gray-500" />
    }
  }

  const getNotificationColor = (type: string) => {
    switch (type) {
      case "ISSUE_REPORTED":
        return "bg-blue-50 border-blue-200"
      case "ISSUE_ASSIGNED":
        return "bg-yellow-50 border-yellow-200"
      case "ISSUE_IN_PROGRESS":
        return "bg-blue-50 border-blue-200"
      case "ISSUE_RESOLVED":
        return "bg-green-50 border-green-200"
      case "ISSUE_REJECTED":
        return "bg-red-50 border-red-200"
      default:
        return "bg-gray-50 border-gray-200"
    }
  }

  const markAsRead = (notificationId: string) => {
    setNotifications(prev => 
      prev.map(notification => 
        notification.id === notificationId 
          ? { ...notification, read: true }
          : notification
      )
    )
    setUnreadCount(prev => Math.max(0, prev - 1))
  }

  const markAllAsRead = () => {
    setNotifications(prev => 
      prev.map(notification => ({ ...notification, read: true }))
    )
    setUnreadCount(0)
  }

  const removeNotification = (notificationId: string) => {
    setNotifications(prev => prev.filter(n => n.id !== notificationId))
    if (!notifications.find(n => n.id === notificationId)?.read) {
      setUnreadCount(prev => Math.max(0, prev - 1))
    }
  }

  const formatTimeAgo = (dateString: string) => {
    const date = new Date(dateString)
    const now = new Date()
    const diffInMinutes = Math.floor((now.getTime() - date.getTime()) / (1000 * 60))
    
    if (diffInMinutes < 1) return "Just now"
    if (diffInMinutes < 60) return `${diffInMinutes}m ago`
    
    const diffInHours = Math.floor(diffInMinutes / 60)
    if (diffInHours < 24) return `${diffInHours}h ago`
    
    const diffInDays = Math.floor(diffInHours / 24)
    return `${diffInDays}d ago`
  }

  return (
    <div className="relative">
      <Dialog open={isOpen} onOpenChange={setIsOpen}>
        <DialogTrigger asChild>
          <Button variant="ghost" size="sm" className="relative">
            <Bell className="h-5 w-5" />
            {unreadCount > 0 && (
              <Badge 
                variant="destructive" 
                className="absolute -top-2 -right-2 h-5 w-5 flex items-center justify-center p-0 text-xs"
              >
                {unreadCount > 99 ? "99+" : unreadCount}
              </Badge>
            )}
          </Button>
        </DialogTrigger>
        <DialogContent className="sm:max-w-[500px] max-h-[80vh] p-0">
          <DialogHeader className="p-6 pb-0">
            <div className="flex items-center justify-between">
              <DialogTitle>Notifications</DialogTitle>
              <div className="flex items-center gap-2">
                {unreadCount > 0 && (
                  <Button variant="ghost" size="sm" onClick={markAllAsRead}>
                    Mark all as read
                  </Button>
                )}
                <Button variant="ghost" size="sm" onClick={() => setIsOpen(false)}>
                  <X className="h-4 w-4" />
                </Button>
              </div>
            </div>
            <DialogDescription>
              Stay updated on your reported issues
            </DialogDescription>
          </DialogHeader>
          
          <ScrollArea className="max-h-[60vh] p-6 pt-0">
            {loading ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <Bell className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-500">Loading notifications...</p>
                </div>
              </div>
            ) : notifications.length === 0 ? (
              <div className="flex items-center justify-center py-8">
                <div className="text-center">
                  <Bell className="h-8 w-8 mx-auto mb-2 text-gray-400" />
                  <p className="text-gray-500">No notifications yet</p>
                </div>
              </div>
            ) : (
              <div className="space-y-4">
                {notifications.map((notification) => (
                  <Card 
                    key={notification.id} 
                    className={`${getNotificationColor(notification.type)} ${!notification.read ? 'shadow-sm' : ''}`}
                  >
                    <CardContent className="p-4">
                      <div className="flex items-start justify-between">
                        <div className="flex items-start gap-3 flex-1">
                          <div className="mt-0.5">
                            {getNotificationIcon(notification.type)}
                          </div>
                          <div className="flex-1 min-w-0">
                            <div className="flex items-center gap-2 mb-1">
                              <h4 className={`font-medium ${!notification.read ? 'text-gray-900' : 'text-gray-700'}`}>
                                {notification.title}
                              </h4>
                              {!notification.read && (
                                <div className="h-2 w-2 bg-blue-500 rounded-full" />
                              )}
                            </div>
                            <p className={`text-sm ${!notification.read ? 'text-gray-700' : 'text-gray-500'} mb-2`}>
                              {notification.message}
                            </p>
                            {notification.issue && (
                              <div className="flex items-center gap-2 text-xs text-gray-500">
                                <span className="font-medium">Issue:</span>
                                <span className="truncate">{notification.issue.title}</span>
                                <Badge variant="outline" className="text-xs">
                                  {notification.issue.status.replace('_', ' ')}
                                </Badge>
                              </div>
                            )}
                            <div className="flex items-center justify-between mt-2">
                              <span className="text-xs text-gray-500">
                                {formatTimeAgo(notification.createdAt)}
                              </span>
                              {!notification.read && (
                                <Button 
                                  variant="ghost" 
                                  size="sm" 
                                  className="text-xs h-6"
                                  onClick={() => markAsRead(notification.id)}
                                >
                                  Mark as read
                                </Button>
                              )}
                            </div>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          className="h-6 w-6 p-0 opacity-50 hover:opacity-100"
                          onClick={() => removeNotification(notification.id)}
                        >
                          <X className="h-3 w-3" />
                        </Button>
                      </div>
                    </CardContent>
                  </Card>
                ))}
              </div>
            )}
          </ScrollArea>
        </DialogContent>
      </Dialog>
    </div>
  )
}