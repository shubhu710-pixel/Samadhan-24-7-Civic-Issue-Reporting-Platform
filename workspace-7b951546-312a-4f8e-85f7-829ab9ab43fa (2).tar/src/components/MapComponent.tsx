'use client'

import { useEffect, useState } from 'react'
import dynamic from 'next/dynamic'
import 'leaflet/dist/leaflet.css'

// Dynamically import the map components to avoid SSR issues
const MapContainer = dynamic(
  () => import('react-leaflet').then((mod) => mod.MapContainer),
  { ssr: false }
)
const TileLayer = dynamic(
  () => import('react-leaflet').then((mod) => mod.TileLayer),
  { ssr: false }
)
const Marker = dynamic(
  () => import('react-leaflet').then((mod) => mod.Marker),
  { ssr: false }
)
const Popup = dynamic(
  () => import('react-leaflet').then((mod) => mod.Popup),
  { ssr: false }
)

interface MapComponentProps {
  latitude?: number
  longitude?: number
  onLocationSelect?: (lat: number, lng: number) => void
  height?: string
  editable?: boolean
}

export default function MapComponent({
  latitude = 40.7128, // Default to NYC
  longitude = -74.0060,
  onLocationSelect,
  height = '400px',
  editable = false
}: MapComponentProps) {
  const [position, setPosition] = useState<[number, number]>([latitude, longitude])
  const [isClient, setIsClient] = useState(false)

  useEffect(() => {
    setIsClient(true)
    if (latitude && longitude) {
      setPosition([latitude, longitude])
    }
  }, [latitude, longitude])

  const handleMapClick = (e: any) => {
    if (editable && onLocationSelect) {
      const { lat, lng } = e.latlng
      setPosition([lat, lng])
      onLocationSelect(lat, lng)
    }
  }

  if (!isClient) {
    return (
      <div 
        className="bg-gray-100 rounded-lg flex items-center justify-center"
        style={{ height }}
      >
        <div className="text-gray-500">Loading map...</div>
      </div>
    )
  }

  return (
    <div className="relative rounded-lg overflow-hidden" style={{ height }}>
      <MapContainer
        center={position}
        zoom={13}
        style={{ height: '100%', width: '100%' }}
        className="z-0"
        onClick={handleMapClick}
      >
        <TileLayer
          url="https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png"
          attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
        />
        <Marker position={position}>
          <Popup>
            {editable ? 'Click to move marker' : 'Issue location'}
          </Popup>
        </Marker>
      </MapContainer>
      {editable && (
        <div className="absolute top-2 left-2 bg-white p-2 rounded shadow-md text-sm">
          Click on the map to set location
        </div>
      )}
    </div>
  )
}