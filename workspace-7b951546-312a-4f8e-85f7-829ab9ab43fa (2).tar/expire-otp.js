// OTP Expiration Utility for Development
// This manually expires OTPs for testing purposes

const baseUrl = 'http://localhost:3000';

async function expireOTP(email) {
  console.log(`⏰ Manually expiring OTP for: ${email}`);
  console.log('='.repeat(50));
  
  try {
    // First check current status
    console.log('📋 Current status:');
    const statusResponse = await fetch(`${baseUrl}/api/otp/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });
    
    const statusData = await statusResponse.json();
    console.log(JSON.stringify(statusData, null, 2));
    
    if (!statusData.hasActiveOTP) {
      console.log('✅ No active OTP found, nothing to expire');
      return;
    }
    
    // For development, we can't directly expire OTPs via API
    // But we can wait for natural expiration or use a fresh email
    console.log('\n💡 Options:');
    console.log('1. Wait for natural expiration (10 minutes)');
    console.log('2. Use a different email address');
    console.log('3. Check server logs for existing OTP and verify it');
    
    // Show existing OTP from logs
    console.log('\n🔍 Checking for existing OTP in logs...');
    const { execSync } = require('child_process');
    try {
      const logOutput = execSync(`grep "OTP for ${email}" /home/z/my-project/dev.log | tail -1`, { encoding: 'utf8' });
      console.log('Found in logs:', logOutput.trim());
      
      // Extract OTP from log
      const match = logOutput.match(/OTP for .*?: (\d{6})/);
      if (match) {
        const otp = match[1];
        console.log(`\n🎯 Extracted OTP: ${otp}`);
        console.log('You can use this OTP to verify the existing one');
        
        // Test verification
        console.log('\n🧪 Testing verification with existing OTP...');
        const verifyResponse = await fetch(`${baseUrl}/api/otp/verify`, {
          method: 'POST',
          headers: {
            'Content-Type': 'application/json',
          },
          body: JSON.stringify({ email, otp }),
        });
        
        const verifyData = await verifyResponse.json();
        console.log('Verification result:', JSON.stringify(verifyData, null, 2));
      }
    } catch (error) {
      console.log('No existing OTP found in logs');
    }
    
  } catch (error) {
    console.log('❌ Error:', error.message);
  }
}

// Run with provided email or default
const email = process.argv[2] || 'demo@example.com';
expireOTP(email).catch(console.error);