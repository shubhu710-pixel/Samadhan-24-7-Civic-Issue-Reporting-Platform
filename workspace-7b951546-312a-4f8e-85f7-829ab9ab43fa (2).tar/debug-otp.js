// OTP Debug Utility
// This helps debug OTP issues by showing current state

const baseUrl = 'http://localhost:3000';

async function checkOTPStatus(email) {
  console.log(`\n🔍 Checking OTP status for: ${email}`);
  console.log('='.repeat(50));
  
  try {
    const response = await fetch(`${baseUrl}/api/otp/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });
    
    const data = await response.json();
    console.log('Status Response:', JSON.stringify(data, null, 2));
    
    return data;
  } catch (error) {
    console.log('❌ Error checking status:', error.message);
    return null;
  }
}

async function sendOTP(email) {
  console.log(`\n📧 Sending OTP for: ${email}`);
  console.log('='.repeat(50));
  
  try {
    const response = await fetch(`${baseUrl}/api/otp/send`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });
    
    const data = await response.json();
    console.log('Send Response:', JSON.stringify(data, null, 2));
    console.log('HTTP Status:', response.status);
    
    return { data, status: response.status };
  } catch (error) {
    console.log('❌ Error sending OTP:', error.message);
    return null;
  }
}

async function verifyOTP(email, otp) {
  console.log(`\n✅ Verifying OTP for: ${email}`);
  console.log('OTP:', otp);
  console.log('='.repeat(50));
  
  try {
    const response = await fetch(`${baseUrl}/api/otp/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, otp }),
    });
    
    const data = await response.json();
    console.log('Verify Response:', JSON.stringify(data, null, 2));
    console.log('HTTP Status:', response.status);
    
    return { data, status: response.status };
  } catch (error) {
    console.log('❌ Error verifying OTP:', error.message);
    return null;
  }
}

// Main debug function
async function debugOTP(email) {
  console.log('🔧 OTP Debug Utility');
  console.log('Email:', email);
  console.log('Base URL:', baseUrl);
  
  // Check initial status
  await checkOTPStatus(email);
  
  // Try to send OTP
  await sendOTP(email);
  
  // Check status after sending
  await checkOTPStatus(email);
  
  // Get the OTP from server logs (this is just for info)
  console.log('\n💡 Tip: Check the server logs for the OTP code:');
  console.log('   grep "OTP for ' + email + '" /home/z/my-project/dev.log | tail -1');
}

// Run with provided email or default
const email = process.argv[2] || 'test@example.com';
debugOTP(email).catch(console.error);