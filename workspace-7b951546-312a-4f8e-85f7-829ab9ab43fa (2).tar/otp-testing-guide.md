# OTP Testing Guide

## 🎯 Common Issues and Solutions

### Issue 1: "OTP already sent"
**Cause**: You've sent an OTP to this email address within the last 10 minutes.
**Solution**: 
- Wait 10 minutes for the OTP to expire
- Use a different email address
- Check the server logs for the existing OTP and use it

### Issue 2: "OTP expired"
**Cause**: The OTP is older than 10 minutes.
**Solution**:
- Request a new OTP
- Use a different email address

## 🧪 Testing Commands

### 1. Check OTP Status
```bash
curl -X POST http://localhost:3000/api/otp/status \
  -H "Content-Type: application/json" \
  -d '{"email":"your@email.com"}'
```

### 2. Send OTP
```bash
curl -X POST http://localhost:3000/api/otp/send \
  -H "Content-Type: application/json" \
  -d '{"email":"your@email.com"}'
```

### 3. Verify OTP
```bash
curl -X POST http://localhost:3000/api/otp/verify \
  -H "Content-Type: application/json" \
  -d '{"email":"your@email.com", "otp":"123456"}'
```

## 🔍 Debug Utilities

### Use Debug Script
```bash
node debug-otp.js your@email.com
```

### Find OTP in Server Logs
```bash
grep "OTP for your@email.com" /home/z/my-project/dev.log | tail -1
```

### Manual Expiration Check
```bash
node expire-otp.js your@email.com
```

## 📱 Testing via Web Interface

### Step 1: Open Application
Navigate to `http://localhost:3000`

### Step 2: Click Register
Click the "Register" button in the top-right corner

### Step 3: Fill Registration Form
- **Full Name**: Enter any name
- **Email**: Use a unique email (e.g., `test123@example.com`)
- **Password**: Enter a password (min 6 characters)

### Step 4: Get OTP
- Click "Create Account"
- Check browser console (F12) for OTP
- Or check server logs: `grep "OTP for" /home/z/my-project/dev.log | tail -1`

### Step 5: Verify OTP
- Enter the 6-digit OTP in the verification modal
- Click "Verify OTP"

## 🎯 Quick Test Emails

Use these for quick testing:
- `user1@example.com`
- `user2@example.com`
- `test123@example.com`
- `demo@example.com`

## ⚡ Rate Limiting Info

- **Duration**: 10 minutes
- **Attempts**: 3 attempts per OTP
- **Expiration**: OTP expires after 10 minutes
- **Cleanup**: Expired OTPs are automatically cleaned up

## 🔧 Development Tips

1. **Use unique emails** for each test to avoid rate limiting
2. **Check server logs** for OTP codes in development mode
3. **Wait 10 minutes** or use different emails if you get "OTP already sent"
4. **Browser console** shows OTP codes in development mode

## 📋 Complete Test Flow

```bash
# 1. Test with fresh email
node debug-otp.js fresh@example.com

# 2. Extract OTP from logs
grep "OTP for fresh@example.com" /home/z/my-project/dev.log | tail -1

# 3. Verify the OTP (replace XXXXXX with actual OTP)
curl -X POST http://localhost:3000/api/otp/verify \
  -H "Content-Type: application/json" \
  -d '{"email":"fresh@example.com", "otp":"XXXXXX"}'

# 4. Check final status
node debug-otp.js fresh@example.com
```

## 🎉 Success Indicators

✅ **OTP Sent**: Status 200 with `devOTP` field  
✅ **OTP Verified**: Status 200 with `emailVerified: true`  
✅ **Rate Limiting**: Status 429 with "OTP already sent"  
✅ **Wrong OTP**: Status 400 with "Invalid OTP"