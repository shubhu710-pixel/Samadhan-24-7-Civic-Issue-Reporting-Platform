"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { MapPin, Camera, Send, Shield, User, LogOut, UserPlus, CheckCircle, Clock, AlertTriangle } from "lucide-react"
import AdminDashboard from "@/components/AdminDashboard"
import NotificationSystem from "@/components/NotificationSystem"
import AuthModal from "@/components/AuthModal"
import ImageUpload from "@/components/ImageUpload"
import IssueCard from "@/components/IssueCard"
import MapComponent from "@/components/MapComponent"
import GPSButton from "@/components/GPSButton"
import { useAuth } from "@/contexts/AuthContext"

export default function Home() {
  const { user, login, logout, isAuthenticated, hasRole, isLoading } = useAuth()
  const [isReportDialogOpen, setIsReportDialogOpen] = useState(false)
  const [selectedIssueType, setSelectedIssueType] = useState("")
  const [selectedPriority, setSelectedPriority] = useState("")
  const [location, setLocation] = useState("")
  const [description, setDescription] = useState("")
  const [imageUrl, setImageUrl] = useState("")
  const [latitude, setLatitude] = useState<number | null>(null)
  const [longitude, setLongitude] = useState<number | null>(null)
  const [isAdminMode, setIsAdminMode] = useState(false)
  const [isAuthModalOpen, setIsAuthModalOpen] = useState(false)
  const [issueTypes, setIssueTypes] = useState<Array<{id: string, name: string, description?: string, icon?: string}>>([])
  const [isLoadingIssueTypes, setIsLoadingIssueTypes] = useState(true)

  // Fetch issue types from API - Updated to handle 403 errors
  useEffect(() => {
    const fetchIssueTypes = async () => {
      try {
        console.log('Fetching issue types...')
        // Use absolute URL for deployed environment
        const apiUrl = process.env.NODE_ENV === 'production' 
          ? 'https://p0sx6770v1u1-deploy.space.z.ai/api/issue-types'
          : '/api/issue-types'
        
        const response = await fetch(apiUrl)
        console.log('Issue types response status:', response.status)
        
        if (response.ok) {
          const data = await response.json()
          console.log('Issue types data:', data)
          console.log('Issue types data length:', data.length)
          setIssueTypes(data)
          
          // If data is empty, use fallback
          if (data.length === 0) {
            console.log('Issue types array is empty, using fallback data')
            setIssueTypes([
              { id: "1", name: "Pothole", icon: "🕳️" },
              { id: "2", name: "Broken Streetlight", icon: "💡" },
              { id: "3", name: "Sanitation Issue", icon: "🗑️" },
              { id: "4", name: "Road Damage", icon: "🛣️" },
              { id: "5", name: "Traffic Signal", icon: "🚦" },
              { id: "6", name: "Other", icon: "📝" }
            ])
          }
        } else if (response.status === 403) {
          // Handle 403 Forbidden error - try absolute URL as fallback
          console.log('Issue types API returned 403, trying absolute URL...')
          try {
            const fallbackResponse = await fetch('https://p0sx6770v1u1-deploy.space.z.ai/api/issue-types')
            if (fallbackResponse.ok) {
              const data = await fallbackResponse.json()
              console.log('Issue types data from absolute URL:', data)
              setIssueTypes(data)
            } else {
              throw new Error('Absolute URL also failed')
            }
          } catch (fallbackError) {
            console.log('Absolute URL failed, using fallback data')
            setIssueTypes([
              { id: "1", name: "Pothole", icon: "🕳️" },
              { id: "2", name: "Broken Streetlight", icon: "💡" },
              { id: "3", name: "Sanitation Issue", icon: "🗑️" },
              { id: "4", name: "Road Damage", icon: "🛣️" },
              { id: "5", name: "Traffic Signal", icon: "🚦" },
              { id: "6", name: "Other", icon: "📝" }
            ])
          }
        } else {
          // Fallback to mock data if API fails
          console.log('Issue types API failed with status:', response.status, 'using fallback data')
          setIssueTypes([
            { id: "1", name: "Pothole", icon: "🕳️" },
            { id: "2", name: "Broken Streetlight", icon: "💡" },
            { id: "3", name: "Sanitation Issue", icon: "🗑️" },
            { id: "4", name: "Road Damage", icon: "🛣️" },
            { id: "5", name: "Traffic Signal", icon: "🚦" },
            { id: "6", name: "Other", icon: "📝" }
          ])
        }
      } catch (error) {
        console.error('Error fetching issue types:', error)
        // Try absolute URL as last resort
        try {
          console.log('Trying absolute URL as last resort...')
          const fallbackResponse = await fetch('https://p0sx6770v1u1-deploy.space.z.ai/api/issue-types')
          if (fallbackResponse.ok) {
            const data = await fallbackResponse.json()
            console.log('Issue types data from absolute URL:', data)
            setIssueTypes(data)
          } else {
            throw new Error('Absolute URL also failed')
          }
        } catch (fallbackError) {
          console.log('All attempts failed, using fallback data')
          // Fallback to mock data
          setIssueTypes([
            { id: "1", name: "Pothole", icon: "🕳️" },
            { id: "2", name: "Broken Streetlight", icon: "💡" },
            { id: "3", name: "Sanitation Issue", icon: "🗑️" },
            { id: "4", name: "Road Damage", icon: "🛣️" },
            { id: "5", name: "Traffic Signal", icon: "🚦" },
            { id: "6", name: "Other", icon: "📝" }
          ])
        }
      } finally {
        setIsLoadingIssueTypes(false)
        console.log('Final issue types state:', issueTypes)
      }
    }

    fetchIssueTypes()
  }, [])

  const priorities = [
    { value: "LOW", label: "Low", color: "bg-green-100 text-green-800" },
    { value: "MEDIUM", label: "Medium", color: "bg-yellow-100 text-yellow-800" },
    { value: "HIGH", label: "High", color: "bg-orange-100 text-orange-800" },
    { value: "URGENT", label: "Urgent", color: "bg-red-100 text-red-800" }
  ]

  const mockIssues = [
    {
      id: "1",
      title: "Large pothole on Main Street",
      description: "There's a large pothole that could damage vehicles",
      location: "123 Main Street",
      latitude: 40.7128,
      longitude: -74.0060,
      status: "IN_PROGRESS",
      priority: "HIGH",
      type: "Pothole",
      imageUrl: "/uploads/demo-pothole.jpg",
      createdAt: "2024-01-15T10:30:00Z"
    },
    {
      id: "2",
      title: "Broken streetlight near park",
      description: "Streetlight has been out for a week, making the area unsafe at night",
      location: "456 Park Avenue",
      latitude: 40.7580,
      longitude: -73.9855,
      status: "REPORTED",
      priority: "MEDIUM",
      type: "Broken Streetlight",
      imageUrl: "/uploads/demo-streetlight.jpg",
      createdAt: "2024-01-14T15:45:00Z"
    },
    {
      id: "3",
      title: "Overflowing garbage bin",
      description: "Public garbage bin is overflowing and attracting pests",
      location: "789 Oak Street",
      latitude: 40.7505,
      longitude: -73.9934,
      status: "RESOLVED",
      priority: "LOW",
      type: "Sanitation Issue",
      imageUrl: "/uploads/demo-garbage.jpg",
      createdAt: "2024-01-13T09:15:00Z"
    }
  ]

  const handleLocationSelect = (lat: number, lng: number) => {
    setLatitude(lat)
    setLongitude(lng)
    // Optionally reverse geocode to get address
    setLocation(`Lat: ${lat.toFixed(6)}, Lng: ${lng.toFixed(6)}`)
  }

  const handleSubmitReport = async () => {
    if (!selectedIssueType || !selectedPriority || !location || !description) {
      alert('Please fill in all required fields')
      return
    }

    // Check if issue types are loaded
    if (isLoadingIssueTypes || issueTypes.length === 0) {
      alert('Issue types are still loading. Please wait and try again.')
      return
    }

    try {
      // Debug: Check what we're working with
      console.log('Debug - selectedIssueType:', selectedIssueType)
      console.log('Debug - issueTypes array:', issueTypes)
      console.log('Debug - issueTypes array length:', issueTypes.length)
      
      // Get issue type ID from the name
      const issueType = issueTypes.find(type => type.name === selectedIssueType)
      console.log('Debug - found issueType:', issueType)
      
      if (!issueType) {
        console.error('Debug - Issue type not found. Selected:', selectedIssueType, 'Available:', issueTypes.map(t => t.name))
        
        // Try to find by ID as fallback
        const issueTypeById = issueTypes.find(type => type.id === selectedIssueType)
        if (issueTypeById) {
          console.log('Debug - Found issue type by ID:', issueTypeById)
          // Use this issue type instead
        } else {
          // Last resort: use the first issue type or a default
          const fallbackIssueType = issueTypes[0] || { id: "1", name: "Other", icon: "📝" }
          console.log('Debug - Using fallback issue type:', fallbackIssueType)
          alert('Invalid issue type selected. Using default: ' + fallbackIssueType.name)
          // Continue with fallback issue type
        }
      }

      const finalIssueType = issueType || issueTypeById || issueTypes[0] || { id: "1", name: "Other", icon: "📝" }
      
      console.log('Debug - Final issue type being used:', finalIssueType)
      console.log('Debug - API request data:', {
        title: selectedIssueType,
        description,
        location,
        latitude,
        longitude,
        issueTypeId: finalIssueType.id,
        priority: selectedPriority,
        reporterId: user?.id,
        imageUrl
      })

      // Use absolute URL for deployed environment
      const apiUrl = process.env.NODE_ENV === 'production' 
        ? 'https://p0sx6770v1u1-deploy.space.z.ai/api/issues'
        : '/api/issues'
      
      const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          title: selectedIssueType,
          description,
          location,
          latitude,
          longitude,
          issueTypeId: finalIssueType.id,
          priority: selectedPriority,
          reporterId: user?.id,
          imageUrl
        }),
      })

      if (response.ok) {
        const issue = await response.json()
        console.log('Issue created:', issue)
        
        // Reset form
        setSelectedIssueType("")
        setSelectedPriority("")
        setLocation("")
        setDescription("")
        setImageUrl("")
        setLatitude(null)
        setLongitude(null)
        setIsReportDialogOpen(false)
        
        alert('Issue reported successfully!')
      } else {
        const error = await response.json()
        alert('Failed to report issue: ' + error.error)
      }
    } catch (error) {
      console.error('Error reporting issue:', error)
      alert('Failed to report issue. Please try again.')
    }
  }

  const handleAuthSuccess = () => {
    // If user is admin, switch to admin mode
    if (hasRole("ADMIN")) {
      setIsAdminMode(true)
    }
  }

  const handleAdminLogout = () => {
    setIsAdminMode(false)
  }

  if (isAdminMode) {
    return <AdminDashboard onClose={handleAdminLogout} />
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 to-indigo-100">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">CityFix</h1>
              <span className="ml-2 text-sm text-gray-500">Urban Issue Reporting</span>
            </div>
            <div className="flex items-center gap-4">
              {isAuthenticated ? (
                <>
                  {hasRole("ADMIN") && (
                    <Button 
                      variant="outline" 
                      className="border-gray-300"
                      onClick={() => setIsAdminMode(true)}
                    >
                      <Shield className="h-4 w-4 mr-2" />
                      Admin Dashboard
                    </Button>
                  )}
                  
                  <NotificationSystem userId={user?.id || ""} />
                  
                  <div className="flex items-center gap-2">
                    <Avatar className="h-8 w-8">
                      <AvatarFallback>
                        {user?.name?.charAt(0) || user?.email?.charAt(0) || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="hidden sm:block">
                      <div className="text-sm font-medium">{user?.name || "User"}</div>
                      <div className="text-xs text-gray-500">{user?.role}</div>
                    </div>
                    <Button variant="ghost" size="sm" onClick={logout}>
                      <LogOut className="h-4 w-4" />
                    </Button>
                  </div>
                </>
              ) : (
                <div className="flex items-center gap-2">
                  <Button variant="outline" onClick={() => setIsAuthModalOpen(true)}>
                    <User className="h-4 w-4 mr-2" />
                    Sign In
                  </Button>
                  <Button onClick={() => setIsAuthModalOpen(true)}>
                    <UserPlus className="h-4 w-4 mr-2" />
                    Register
                  </Button>
                </div>
              )}
            </div>
            
            <div className="flex items-center">
              <Dialog open={isReportDialogOpen} onOpenChange={setIsReportDialogOpen}>
                <DialogTrigger asChild>
                  <Button className="bg-blue-600 hover:bg-blue-700" disabled={!isAuthenticated}>
                    <MapPin className="h-4 w-4 mr-2" />
                    Report Issue
                  </Button>
                </DialogTrigger>
              <DialogContent className="sm:max-w-[425px]">
                <DialogHeader>
                  <DialogTitle>Report a New Issue</DialogTitle>
                  <DialogDescription>
                    Help improve our city by reporting local issues. Your report will be sent to the appropriate department.
                  </DialogDescription>
                </DialogHeader>
                <div className="grid gap-4 py-4">
                  <div className="grid gap-2">
                    <label htmlFor="issue-type" className="text-sm font-medium">
                      Issue Type
                    </label>
                    {/* Debug info - remove in production */}
                    {process.env.NODE_ENV === 'development' && (
                      <div className="text-xs text-gray-500">
                        Debug: issueTypes length = {issueTypes.length}, isLoading = {isLoadingIssueTypes}
                      </div>
                    )}
                    <Select value={selectedIssueType} onValueChange={(value) => {
                      console.log('Debug - Select onValueChange:', value)
                      setSelectedIssueType(value)
                    }} disabled={isLoadingIssueTypes}>
                      <SelectTrigger>
                        <SelectValue placeholder={isLoadingIssueTypes ? "Loading issue types..." : "Select issue type"} />
                      </SelectTrigger>
                      <SelectContent>
                        {issueTypes.map((type) => (
                          <SelectItem key={type.id} value={type.name}>
                            <div className="flex items-center gap-2">
                              <span>{type.icon || '📝'}</span>
                              <span>{type.name}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid gap-2">
                    <label htmlFor="priority" className="text-sm font-medium">
                      Priority
                    </label>
                    <Select value={selectedPriority} onValueChange={setSelectedPriority}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select priority" />
                      </SelectTrigger>
                      <SelectContent>
                        {priorities.map((priority) => (
                          <SelectItem key={priority.value} value={priority.value}>
                            <div className="flex items-center gap-2">
                              <span className={`px-2 py-1 rounded-full text-xs ${priority.color}`}>
                                {priority.label}
                              </span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>
                  
                  <div className="grid gap-2">
                    <label htmlFor="location" className="text-sm font-medium">
                      Location
                    </label>
                    <Input
                      id="location"
                      placeholder="Enter the address or location"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                    />
                    <GPSButton onLocationFound={handleLocationSelect} />
                    
                    {(latitude && longitude) && (
                      <div className="mt-4">
                        <label className="text-sm font-medium block mb-2">
                          Map Location
                        </label>
                        <MapComponent
                          latitude={latitude}
                          longitude={longitude}
                          onLocationSelect={handleLocationSelect}
                          height="300px"
                          editable={true}
                        />
                      </div>
                    )}
                  </div>
                  
                  <div className="grid gap-2">
                    <label htmlFor="description" className="text-sm font-medium">
                      Description
                    </label>
                    <Textarea
                      id="description"
                      placeholder="Describe the issue in detail..."
                      value={description}
                      onChange={(e) => setDescription(e.target.value)}
                    />
                  </div>
                  
                  <div className="grid gap-2">
                    <label htmlFor="photo" className="text-sm font-medium">
                      Photo (Optional)
                    </label>
                    <ImageUpload 
                      onImageUpload={setImageUrl}
                      currentImage={imageUrl}
                      className="w-full"
                    />
                  </div>
                </div>
                <div className="flex justify-end gap-2">
                  <Button variant="outline" onClick={() => setIsReportDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button onClick={handleSubmitReport} disabled={!selectedIssueType || !location || !description}>
                    <Send className="h-4 w-4 mr-2" />
                    Submit Report
                  </Button>
                </div>
              </DialogContent>
            </Dialog>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Hero Section */}
        <div className="text-center mb-12">
          <h2 className="text-4xl font-bold text-gray-900 mb-4">
            Report Issues. Improve Our City.
          </h2>
          <p className="text-xl text-gray-600 max-w-2xl mx-auto">
            Help make our community better by reporting local issues like potholes, broken streetlights, 
            and sanitation problems. Together, we can create a cleaner, safer city for everyone.
          </p>
        </div>

        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-12">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Reports</CardTitle>
              <MapPin className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">1,247</div>
              <p className="text-xs text-muted-foreground">+20% from last month</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resolved</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">892</div>
              <p className="text-xs text-muted-foreground">71.5% resolution rate</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Progress</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">234</div>
              <p className="text-xs text-muted-foreground">Being addressed</p>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Avg. Resolution Time</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">3.2 days</div>
              <p className="text-xs text-muted-foreground">-15% improvement</p>
            </CardContent>
          </Card>
        </div>

        {/* Recent Issues Section */}
        <div className="bg-white rounded-lg shadow-sm border">
          <div className="p-6 border-b">
            <h3 className="text-lg font-semibold text-gray-900">Recent Issues</h3>
            <p className="text-sm text-gray-600">Latest reported issues in your area</p>
          </div>
          
          <Tabs defaultValue="all" className="w-full">
            <div className="px-6 pt-2">
              <TabsList>
                <TabsTrigger value="all">All Issues</TabsTrigger>
                <TabsTrigger value="reported">Reported</TabsTrigger>
                <TabsTrigger value="in-progress">In Progress</TabsTrigger>
                <TabsTrigger value="resolved">Resolved</TabsTrigger>
              </TabsList>
            </div>
            
            <TabsContent value="all" className="p-6">
              <div className="space-y-4">
                {mockIssues.map((issue) => (
                  <IssueCard key={issue.id} issue={issue} />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="reported" className="p-6">
              <div className="space-y-4">
                {mockIssues.filter(issue => issue.status === "REPORTED").map((issue) => (
                  <IssueCard key={issue.id} issue={issue} />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="in-progress" className="p-6">
              <div className="space-y-4">
                {mockIssues.filter(issue => issue.status === "IN_PROGRESS").map((issue) => (
                  <IssueCard key={issue.id} issue={issue} />
                ))}
              </div>
            </TabsContent>
            
            <TabsContent value="resolved" className="p-6">
              <div className="space-y-4">
                {mockIssues.filter(issue => issue.status === "RESOLVED").map((issue) => (
                  <IssueCard key={issue.id} issue={issue} />
                ))}
              </div>
            </TabsContent>
          </Tabs>
        </div>
      </main>

      {/* Footer */}
      <footer className="bg-white border-t mt-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
          <div className="text-center text-gray-600">
            <p>&copy; 2024 CityFix. Making our cities better, one issue at a time.</p>
          </div>
        </div>
      </footer>
      
      <AuthModal 
        isOpen={isAuthModalOpen} 
        onClose={() => setIsAuthModalOpen(false)}
        onSuccess={handleAuthSuccess}
      />
    </div>
  )
}