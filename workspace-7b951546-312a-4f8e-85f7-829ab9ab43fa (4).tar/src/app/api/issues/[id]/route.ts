import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const issue = await db.issue.findUnique({
      where: { id: params.id },
      include: {
        reporter: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        type: true,
        department: true,
        notifications: {
          orderBy: {
            createdAt: 'desc'
          }
        }
      }
    })

    if (!issue) {
      return NextResponse.json(
        { error: 'Issue not found' },
        { status: 404 }
      )
    }

    return NextResponse.json(issue)
  } catch (error) {
    console.error('Error fetching issue:', error)
    return NextResponse.json(
      { error: 'Failed to fetch issue' },
      { status: 500 }
    )
  }
}

export async function PATCH(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { status, priority, assignedToId, notes } = body

    // Check if issue exists
    const existingIssue = await db.issue.findUnique({
      where: { id: params.id },
      include: {
        reporter: true,
        assignedTo: true
      }
    })

    if (!existingIssue) {
      return NextResponse.json(
        { error: 'Issue not found' },
        { status: 404 }
      )
    }

    const updateData: any = {}
    if (status !== undefined) updateData.status = status
    if (priority !== undefined) updateData.priority = priority
    if (assignedToId !== undefined) updateData.assignedToId = assignedToId || null

    const updatedIssue = await db.issue.update({
      where: { id: params.id },
      data: updateData,
      include: {
        reporter: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        type: true,
        department: true
      }
    })

    // Create notification if status changed
    if (status && status !== existingIssue.status) {
      let notificationTitle = ''
      let notificationMessage = ''
      let notificationType = ''

      switch (status) {
        case 'IN_PROGRESS':
          notificationTitle = 'Issue In Progress'
          notificationMessage = `Your issue "${updatedIssue.title}" is now being addressed.`
          notificationType = 'ISSUE_IN_PROGRESS'
          break
        case 'RESOLVED':
          notificationTitle = 'Issue Resolved'
          notificationMessage = `Your issue "${updatedIssue.title}" has been resolved.`
          notificationType = 'ISSUE_RESOLVED'
          break
        case 'REJECTED':
          notificationTitle = 'Issue Rejected'
          notificationMessage = `Your issue "${updatedIssue.title}" has been rejected.`
          notificationType = 'ISSUE_REJECTED'
          break
      }

      if (notificationTitle) {
        await db.notification.create({
          data: {
            title: notificationTitle,
            message: notificationMessage,
            type: notificationType,
            userId: updatedIssue.reporterId,
            issueId: updatedIssue.id
          }
        })
      }
    }

    // Create notification if issue was assigned
    if (assignedToId && assignedToId !== existingIssue.assignedToId) {
      await db.notification.create({
        data: {
          title: 'Issue Assigned',
          message: `You have been assigned to issue "${updatedIssue.title}".`,
          type: 'ISSUE_ASSIGNED',
          userId: assignedToId,
          issueId: updatedIssue.id
        }
      })
    }

    // Handle notes (this would typically be stored in a separate notes table)
    // For now, we'll just acknowledge that notes were received
    if (notes && notes.trim()) {
      console.log(`Notes added to issue ${params.id}: ${notes}`)
    }

    return NextResponse.json(updatedIssue)
  } catch (error) {
    console.error('Error updating issue:', error)
    return NextResponse.json(
      { error: 'Failed to update issue' },
      { status: 500 }
    )
  }
}

export async function PUT(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const body = await request.json()
    const { title, description, location, latitude, longitude, status, priority, assignedToId } = body

    // Check if issue exists
    const existingIssue = await db.issue.findUnique({
      where: { id: params.id }
    })

    if (!existingIssue) {
      return NextResponse.json(
        { error: 'Issue not found' },
        { status: 404 }
      )
    }

    const updateData: any = {}
    if (title !== undefined) updateData.title = title
    if (description !== undefined) updateData.description = description
    if (location !== undefined) updateData.location = location
    if (latitude !== undefined) updateData.latitude = latitude
    if (longitude !== undefined) updateData.longitude = longitude
    if (status !== undefined) updateData.status = status
    if (priority !== undefined) updateData.priority = priority
    if (assignedToId !== undefined) updateData.assignedToId = assignedToId

    const updatedIssue = await db.issue.update({
      where: { id: params.id },
      data: updateData,
      include: {
        reporter: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        assignedTo: {
          select: {
            id: true,
            name: true,
            email: true
          }
        },
        type: true,
        department: true
      }
    })

    // Create notification if status changed
    if (status && status !== existingIssue.status) {
      let notificationTitle = ''
      let notificationMessage = ''
      let notificationType = ''

      switch (status) {
        case 'IN_PROGRESS':
          notificationTitle = 'Issue In Progress'
          notificationMessage = `Your issue "${updatedIssue.title}" is now being addressed.`
          notificationType = 'ISSUE_IN_PROGRESS'
          break
        case 'RESOLVED':
          notificationTitle = 'Issue Resolved'
          notificationMessage = `Your issue "${updatedIssue.title}" has been resolved.`
          notificationType = 'ISSUE_RESOLVED'
          break
        case 'REJECTED':
          notificationTitle = 'Issue Rejected'
          notificationMessage = `Your issue "${updatedIssue.title}" has been rejected.`
          notificationType = 'ISSUE_REJECTED'
          break
      }

      if (notificationTitle) {
        await db.notification.create({
          data: {
            title: notificationTitle,
            message: notificationMessage,
            type: notificationType,
            userId: updatedIssue.reporterId,
            issueId: updatedIssue.id
          }
        })
      }
    }

    // Create notification if issue was assigned
    if (assignedToId && assignedToId !== existingIssue.assignedToId) {
      await db.notification.create({
        data: {
          title: 'Issue Assigned',
          message: `You have been assigned to issue "${updatedIssue.title}".`,
          type: 'ISSUE_ASSIGNED',
          userId: assignedToId,
          issueId: updatedIssue.id
        }
      })
    }

    return NextResponse.json(updatedIssue)
  } catch (error) {
    console.error('Error updating issue:', error)
    return NextResponse.json(
      { error: 'Failed to update issue' },
      { status: 500 }
    )
  }
}

export async function DELETE(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    // Check if issue exists
    const existingIssue = await db.issue.findUnique({
      where: { id: params.id }
    })

    if (!existingIssue) {
      return NextResponse.json(
        { error: 'Issue not found' },
        { status: 404 }
      )
    }

    // Delete associated notifications first
    await db.notification.deleteMany({
      where: { issueId: params.id }
    })

    // Delete the issue
    await db.issue.delete({
      where: { id: params.id }
    })

    return NextResponse.json({ message: 'Issue deleted successfully' })
  } catch (error) {
    console.error('Error deleting issue:', error)
    return NextResponse.json(
      { error: 'Failed to delete issue' },
      { status: 500 }
    )
  }
}