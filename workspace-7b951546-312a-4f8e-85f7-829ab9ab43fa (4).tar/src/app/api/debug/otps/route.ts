import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

export async function GET(request: NextRequest) {
  try {
    // Get all OTPs
    const otps = await db.oTP.findMany({
      include: {
        user: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    })

    return NextResponse.json({
      otps: otps.map(otp => ({
        id: otp.id,
        email: otp.email,
        user: otp.user,
        otp: otp.otp, // This is hashed
        expiresAt: otp.expiresAt,
        attempts: otp.attempts,
        verified: otp.verified,
        createdAt: otp.createdAt,
        isValid: new Date(otp.expiresAt) > new Date()
      }))
    })

  } catch (error) {
    console.error('Error fetching OTPs:', error)
    return NextResponse.json(
      { error: 'Failed to fetch OTPs' },
      { status: 500 }
    )
  }
}