import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { OTPService } from '@/lib/otp'

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email || !OTPService.isValidEmail(email)) {
      return NextResponse.json(
        { error: 'Valid email is required' },
        { status: 400 }
      )
    }

    // Check if user exists and is verified
    const user = await db.user.findUnique({
      where: { email }
    })

    if (user && user.emailVerified) {
      return NextResponse.json({
        emailVerified: true,
        message: 'Email already verified'
      })
    }

    // Check for active OTP
    const activeOTP = await db.oTP.findFirst({
      where: {
        email,
        verified: false,
        expiresAt: {
          gt: new Date()
        }
      }
    })

    if (activeOTP) {
      const remainingTimeSeconds = OTPService.getRemainingTimeInSeconds({
        ...activeOTP,
        otp: ''
      })

      return NextResponse.json({
        emailVerified: false,
        hasActiveOTP: true,
        remainingTime: Math.ceil(remainingTimeSeconds / 60), // Keep minutes for backward compatibility
        remainingTimeSeconds, // Add seconds for precise timing
        message: 'OTP already sent'
      })
    }

    return NextResponse.json({
      emailVerified: false,
      hasActiveOTP: false,
      message: 'No active OTP found'
    })

  } catch (error) {
    console.error('Error checking OTP status:', error)
    return NextResponse.json(
      { error: 'Failed to check OTP status' },
      { status: 500 }
    )
  }
}