import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { OTPService } from '@/lib/otp'
import { EmailService } from '@/lib/email'

export async function POST(request: NextRequest) {
  try {
    const { email } = await request.json()

    if (!email || !OTPService.isValidEmail(email)) {
      return NextResponse.json(
        { error: 'Valid email is required' },
        { status: 400 }
      )
    }

    // Check if user already exists and is verified
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser && existingUser.emailVerified) {
      return NextResponse.json(
        { error: 'Email already verified' },
        { status: 400 }
      )
    }

    // Check if there's a recent unverified OTP for this email
    const recentOTP = await db.oTP.findFirst({
      where: {
        email,
        verified: false,
        expiresAt: {
          gt: new Date()
        }
      }
    })

    if (recentOTP) {
      const remainingTimeSeconds = OTPService.getRemainingTimeInSeconds({
        ...recentOTP,
        otp: '' // We don't need the actual OTP for this check
      })

      return NextResponse.json(
        { 
          error: 'OTP already sent',
          message: `Please wait ${Math.ceil(remainingTimeSeconds / 60)} minutes before requesting another OTP`,
          retryAfter: remainingTimeSeconds, // Return seconds instead of minutes
          remainingTime: Math.ceil(remainingTimeSeconds / 60), // Keep minutes for backward compatibility
          remainingTimeSeconds // Add seconds for precise timing
        },
        { status: 429 }
      )
    }

    // Delete any existing unverified OTPs for this email
    await db.oTP.deleteMany({
      where: {
        email,
        verified: false
      }
    })

    // Generate new OTP
    const otpData = OTPService.createOTPData(email)
    const hashedOTP = OTPService.hashOTP(otpData.otp)

    // Store OTP in database
    await db.oTP.create({
      data: {
        email,
        otp: hashedOTP,
        expiresAt: otpData.expiresAt,
        attempts: 0,
        verified: false
      }
    })

    // In a real application, you would send an email here
    // For demo purposes, we'll just return the OTP
    // In production, you would use a service like SendGrid, AWS SES, etc.
    
    console.log(`OTP for ${email}: ${otpData.otp}`) // Remove this in production

    // Send OTP email
    const emailSent = await EmailService.sendOTP(email, otpData.otp)

    // Always proceed even if email fails - we'll return the OTP for testing
    console.log(`OTP for ${email}: ${otpData.otp}`) // Remove this in production

    // Clean up expired OTPs
    await cleanupExpiredOTPs()

    return NextResponse.json({
      message: emailSent ? 'OTP sent successfully' : 'OTP generated (email failed)',
      // Return OTP for testing purposes
      devOTP: otpData.otp,
      emailSent: emailSent
    })

  } catch (error) {
    console.error('Error sending OTP:', error)
    return NextResponse.json(
      { error: 'Failed to send OTP' },
      { status: 500 }
    )
  }
}

// Helper function to clean up expired OTPs
async function cleanupExpiredOTPs() {
  try {
    await db.oTP.deleteMany({
      where: {
        OR: [
          {
            expiresAt: {
              lt: new Date()
            }
          },
          {
            verified: true
          }
        ]
      }
    })
  } catch (error) {
    console.error('Error cleaning up expired OTPs:', error)
  }
}