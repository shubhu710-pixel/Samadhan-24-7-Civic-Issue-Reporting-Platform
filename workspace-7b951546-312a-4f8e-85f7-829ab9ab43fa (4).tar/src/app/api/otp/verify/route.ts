import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'
import { OTPService } from '@/lib/otp'

export async function POST(request: NextRequest) {
  try {
    const { email, otp } = await request.json()

    if (!email || !otp || !OTPService.isValidEmail(email)) {
      return NextResponse.json(
        { error: 'Email and OTP are required' },
        { status: 400 }
      )
    }

    // Find the OTP record
    const otpRecord = await db.oTP.findFirst({
      where: {
        email,
        verified: false,
        expiresAt: {
          gt: new Date()
        }
      }
    })

    console.log('OTP Verification Debug - Search parameters:', {
      email,
      verified: false,
      currentTime: new Date(),
      expiresAfter: new Date()
    })

    if (!otpRecord) {
      // Check if there's an expired OTP for debugging
      const expiredOTP = await db.oTP.findFirst({
        where: {
          email,
          verified: false,
          expiresAt: {
            lte: new Date()
          }
        }
      })

      if (expiredOTP) {
        console.log('OTP Verification Debug - Found expired OTP:', {
          email: expiredOTP.email,
          expiresAt: expiredOTP.expiresAt,
          currentTime: new Date(),
          timeDiff: new Date().getTime() - expiredOTP.expiresAt.getTime()
        })
      }

      console.log('OTP Verification Debug - No valid OTP found')
      return NextResponse.json(
        { error: 'Invalid or expired OTP' },
        { status: 400 }
      )
    }

    // Check if attempts are exceeded
    if (otpRecord.attempts >= 3) {
      return NextResponse.json(
        { error: 'Too many attempts. Please request a new OTP' },
        { status: 400 }
      )
    }

    // Verify OTP
    const isValid = OTPService.verifyHashedOTP(otpRecord.otp, otp)

    if (!isValid) {
      // Increment attempts
      await db.oTP.update({
        where: { id: otpRecord.id },
        data: { attempts: otpRecord.attempts + 1 }
      })

      const remainingAttempts = 3 - (otpRecord.attempts + 1)
      return NextResponse.json(
        { 
          error: 'Invalid OTP',
          remainingAttempts,
          message: remainingAttempts > 0 
            ? `${remainingAttempts} attempts remaining` 
            : 'Too many attempts. Please request a new OTP'
        },
        { status: 400 }
      )
    }

    // Mark OTP as verified
    await db.oTP.update({
      where: { id: otpRecord.id },
      data: { verified: true }
    })

    console.log('OTP Verification Debug - OTP marked as verified:', {
      id: otpRecord.id,
      email: otpRecord.email,
      verified: true
    })

    // If user exists, mark email as verified
    const existingUser = await db.user.findUnique({
      where: { email }
    })

    if (existingUser) {
      await db.user.update({
        where: { id: existingUser.id },
        data: { emailVerified: true }
      })
      console.log('OTP Verification Debug - User email marked as verified:', existingUser.email)
    }

    return NextResponse.json({
      message: 'OTP verified successfully',
      emailVerified: true,
      userExists: !!existingUser
    })

  } catch (error) {
    console.error('Error verifying OTP:', error)
    return NextResponse.json(
      { error: 'Failed to verify OTP' },
      { status: 500 }
    )
  }
}