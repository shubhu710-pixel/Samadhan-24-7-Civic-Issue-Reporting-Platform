import { NextRequest, NextResponse } from 'next/server'
import { db } from '@/lib/db'

// Auto-seed function
async function seedDatabaseIfNeeded() {
  try {
    const issueTypesCount = await db.issueType.count()
    
    if (issueTypesCount === 0) {
      console.log('Database is empty, seeding initial data...')
      
      // Create issue types
      const issueTypes = [
        { name: 'Pothole', description: 'Damage to road surface', icon: '🕳️' },
        { name: 'Broken Streetlight', description: 'Streetlight not working', icon: '💡' },
        { name: 'Sanitation Issue', description: 'Garbage, waste, or cleanliness problems', icon: '🗑️' },
        { name: 'Road Damage', description: 'General road surface damage', icon: '🛣️' },
        { name: 'Traffic Signal', description: 'Traffic light or signal issues', icon: '🚦' },
        { name: 'Other', description: 'Other types of issues', icon: '📝' }
      ]

      for (const issueType of issueTypes) {
        await db.issueType.create({
          data: issueType
        })
      }

      // Create departments
      const departments = [
        { name: 'Public Works', description: 'Handles public infrastructure issues', email: 'publicworks@city.gov' },
        { name: 'Sanitation Department', description: 'Handles waste management and cleanliness', email: 'sanitation@city.gov' },
        { name: 'Transportation Department', description: 'Handles traffic and transportation issues', email: 'transportation@city.gov' }
      ]

      for (const dept of departments) {
        await db.department.create({
          data: dept
        })
      }

      console.log('Database seeded successfully!')
    }
  } catch (error) {
    console.error('Error seeding database:', error)
  }
}

export async function GET(request: NextRequest) {
  try {
    // Auto-seed database if needed
    await seedDatabaseIfNeeded()
    
    const issueTypes = await db.issueType.findMany({
      orderBy: {
        name: 'asc'
      }
    })

    return NextResponse.json(issueTypes)
  } catch (error) {
    console.error('Error fetching issue types:', error)
    return NextResponse.json(
      { error: 'Failed to fetch issue types' },
      { status: 500 }
    )
  }
}

export async function POST(request: NextRequest) {
  try {
    const body = await request.json()
    const { name, description, icon } = body

    if (!name) {
      return NextResponse.json(
        { error: 'Name is required' },
        { status: 400 }
      )
    }

    // Check if issue type already exists
    const existingIssueType = await db.issueType.findUnique({
      where: { name }
    })

    if (existingIssueType) {
      return NextResponse.json(
        { error: 'Issue type already exists' },
        { status: 400 }
      )
    }

    const issueType = await db.issueType.create({
      data: {
        name,
        description: description || null,
        icon: icon || '📝'
      }
    })

    return NextResponse.json(issueType, { status: 201 })
  } catch (error) {
    console.error('Error creating issue type:', error)
    return NextResponse.json(
      { error: 'Failed to create issue type' },
      { status: 500 }
    )
  }
}