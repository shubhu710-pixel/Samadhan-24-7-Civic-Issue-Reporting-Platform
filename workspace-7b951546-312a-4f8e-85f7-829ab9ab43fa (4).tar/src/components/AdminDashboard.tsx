"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { 
  MapPin, 
  Camera, 
  Send, 
  AlertTriangle, 
  CheckCircle, 
  Clock, 
  XCircle,
  Users,
  TrendingUp,
  BarChart3,
  Settings,
  LogOut,
  Search,
  Filter,
  MoreHorizontal,
  Eye,
  Edit,
  Trash2
} from "lucide-react"
import MapComponent from "@/components/MapComponent"

interface User {
  id: string
  email: string
  name?: string
  role: string
  createdAt: string
  updatedAt: string
}

interface IssueType {
  id: string
  name: string
  description?: string
  icon?: string
}

interface Department {
  id: string
  name: string
  description?: string
  email?: string
}

interface Issue {
  id: string
  title: string
  description: string
  location: string
  latitude?: number
  longitude?: number
  status: string
  priority: string
  imageUrl?: string
  createdAt: string
  updatedAt: string
  reporter: User
  assignedTo?: User
  type: IssueType
  department: Department
}

interface AdminDashboardProps {
  onClose: () => void
}

export default function AdminDashboard({ onClose }: AdminDashboardProps) {
  const [issues, setIssues] = useState<Issue[]>([])
  const [users, setUsers] = useState<User[]>([])
  const [issueTypes, setIssueTypes] = useState<IssueType[]>([])
  const [departments, setDepartments] = useState<Department[]>([])
  const [selectedIssue, setSelectedIssue] = useState<Issue | null>(null)
  const [isDetailDialogOpen, setIsDetailDialogOpen] = useState(false)
  const [isEditDialogOpen, setIsEditDialogOpen] = useState(false)
  const [searchTerm, setSearchTerm] = useState("")
  const [statusFilter, setStatusFilter] = useState("")
  const [priorityFilter, setPriorityFilter] = useState("")
  const [loading, setLoading] = useState(true)
  const [actionLoading, setActionLoading] = useState(false)
  const [selectedIssues, setSelectedIssues] = useState<string[]>([])
  const [notes, setNotes] = useState("")
  const [assignedStaffId, setAssignedStaffId] = useState("")
  const [newStatus, setNewStatus] = useState("")
  const [newPriority, setNewPriority] = useState("")
  
  // User management state
  const [isCreateUserDialogOpen, setIsCreateUserDialogOpen] = useState(false)
  const [isEditUserDialogOpen, setIsEditUserDialogOpen] = useState(false)
  const [selectedUser, setSelectedUser] = useState<User | null>(null)
  const [newUser, setNewUser] = useState({
    email: '',
    name: '',
    role: 'STAFF',
    password: '',
    confirmPassword: ''
  })
  const [editUser, setEditUser] = useState({
    name: '',
    role: '',
    password: '',
    confirmPassword: ''
  })

  // Mock data for demonstration
  const mockIssues: Issue[] = [
    {
      id: "1",
      title: "Large pothole on Main Street",
      description: "There's a large pothole that could damage vehicles",
      location: "123 Main Street",
      latitude: 40.7128,
      longitude: -74.0060,
      status: "IN_PROGRESS",
      priority: "HIGH",
      createdAt: "2024-01-15T10:30:00Z",
      updatedAt: "2024-01-15T10:30:00Z",
      reporter: {
        id: "1",
        email: "citizen@example.com",
        name: "John Citizen",
        role: "CITIZEN",
        createdAt: "2024-01-01T00:00:00Z",
        updatedAt: "2024-01-01T00:00:00Z"
      },
      type: {
        id: "1",
        name: "Pothole",
        description: "Damage to road surface",
        icon: "🕳️"
      },
      department: {
        id: "1",
        name: "Public Works",
        description: "Handles public infrastructure issues",
        email: "publicworks@city.gov"
      }
    },
    {
      id: "2",
      title: "Broken streetlight near park",
      description: "Streetlight has been out for a week, making the area unsafe at night",
      location: "456 Park Avenue",
      latitude: 40.7580,
      longitude: -73.9855,
      status: "REPORTED",
      priority: "MEDIUM",
      createdAt: "2024-01-14T15:45:00Z",
      updatedAt: "2024-01-14T15:45:00Z",
      reporter: {
        id: "1",
        email: "citizen@example.com",
        name: "John Citizen",
        role: "CITIZEN",
        createdAt: "2024-01-01T00:00:00Z",
        updatedAt: "2024-01-01T00:00:00Z"
      },
      type: {
        id: "2",
        name: "Broken Streetlight",
        description: "Streetlight not working",
        icon: "💡"
      },
      department: {
        id: "1",
        name: "Public Works",
        description: "Handles public infrastructure issues",
        email: "publicworks@city.gov"
      }
    },
    {
      id: "3",
      title: "Overflowing garbage bin",
      description: "Public garbage bin is overflowing and attracting pests",
      location: "789 Oak Street",
      latitude: 40.7505,
      longitude: -73.9934,
      status: "RESOLVED",
      priority: "LOW",
      createdAt: "2024-01-13T09:15:00Z",
      updatedAt: "2024-01-13T09:15:00Z",
      reporter: {
        id: "1",
        email: "citizen@example.com",
        name: "John Citizen",
        role: "CITIZEN",
        createdAt: "2024-01-01T00:00:00Z",
        updatedAt: "2024-01-01T00:00:00Z"
      },
      type: {
        id: "3",
        name: "Sanitation Issue",
        description: "Garbage, waste, or cleanliness problems",
        icon: "🗑️"
      },
      department: {
        id: "2",
        name: "Sanitation Department",
        description: "Handles waste management and cleanliness",
        email: "sanitation@city.gov"
      }
    }
  ]

  const mockUsers: User[] = [
    {
      id: "1",
      email: "citizen@example.com",
      name: "John Citizen",
      role: "CITIZEN",
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z"
    },
    {
      id: "2",
      email: "admin@city.gov",
      name: "City Administrator",
      role: "ADMIN",
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z"
    },
    {
      id: "3",
      email: "staff@city.gov",
      name: "City Staff",
      role: "STAFF",
      createdAt: "2024-01-01T00:00:00Z",
      updatedAt: "2024-01-01T00:00:00Z"
    }
  ]

  const mockIssueTypes: IssueType[] = [
    {
      id: "1",
      name: "Pothole",
      description: "Damage to road surface",
      icon: "🕳️"
    },
    {
      id: "2",
      name: "Broken Streetlight",
      description: "Streetlight not working",
      icon: "💡"
    },
    {
      id: "3",
      name: "Sanitation Issue",
      description: "Garbage, waste, or cleanliness problems",
      icon: "🗑️"
    },
    {
      id: "4",
      name: "Road Damage",
      description: "General road surface damage",
      icon: "🛣️"
    },
    {
      id: "5",
      name: "Traffic Signal",
      description: "Traffic light or signal issues",
      icon: "🚦"
    },
    {
      id: "6",
      name: "Other",
      description: "Other types of issues",
      icon: "📝"
    }
  ]

  const mockDepartments: Department[] = [
    {
      id: "1",
      name: "Public Works",
      description: "Handles public infrastructure issues",
      email: "publicworks@city.gov"
    },
    {
      id: "2",
      name: "Sanitation Department",
      description: "Handles waste management and cleanliness",
      email: "sanitation@city.gov"
    },
    {
      id: "3",
      name: "Transportation Department",
      description: "Handles traffic and transportation issues",
      email: "transportation@city.gov"
    },
    {
      id: "4",
      name: "Parks and Recreation",
      description: "Handles parks and public spaces",
      email: "parks@city.gov"
    }
  ]

  useEffect(() => {
    // Fetch real data from API
    const fetchData = async () => {
      try {
        setLoading(true)
        
        // Fetch issues
        const issuesResponse = await fetch('/api/issues')
        const issuesData = await issuesResponse.json()
        setIssues(issuesData.issues || [])
        
        // Fetch users
        const usersResponse = await fetch('/api/users')
        const usersData = await usersResponse.json()
        setUsers(usersData)
        
        // Fetch issue types
        const issueTypesResponse = await fetch('/api/issue-types')
        const issueTypesData = await issueTypesResponse.json()
        setIssueTypes(issueTypesData)
        
        // Fetch departments
        const departmentsResponse = await fetch('/api/departments')
        const departmentsData = await departmentsResponse.json()
        setDepartments(departmentsData)
        
      } catch (error) {
        console.error('AdminDashboard: Error fetching data:', error)
        // Fallback to mock data if API fails
        setIssues(mockIssues)
        setUsers(mockUsers)
        setIssueTypes(mockIssueTypes)
        setDepartments(mockDepartments)
      } finally {
        setLoading(false)
      }
    }

    fetchData()
  }, [])

  const getStatusIcon = (status: string) => {
    switch (status) {
      case "REPORTED":
        return <AlertTriangle className="h-4 w-4" />
      case "IN_PROGRESS":
        return <Clock className="h-4 w-4" />
      case "RESOLVED":
        return <CheckCircle className="h-4 w-4" />
      case "REJECTED":
        return <XCircle className="h-4 w-4" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "REPORTED":
        return "bg-yellow-100 text-yellow-800"
      case "IN_PROGRESS":
        return "bg-blue-100 text-blue-800"
      case "RESOLVED":
        return "bg-green-100 text-green-800"
      case "REJECTED":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "LOW":
        return "bg-green-100 text-green-800"
      case "MEDIUM":
        return "bg-yellow-100 text-yellow-800"
      case "HIGH":
        return "bg-orange-100 text-orange-800"
      case "URGENT":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const filteredIssues = issues.filter(issue => {
    const matchesSearch = issue.title.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         issue.description.toLowerCase().includes(searchTerm.toLowerCase()) ||
                         issue.location.toLowerCase().includes(searchTerm.toLowerCase())
    const matchesStatus = !statusFilter || statusFilter === "all" || issue.status === statusFilter
    const matchesPriority = !priorityFilter || priorityFilter === "all" || issue.priority === priorityFilter
    
    return matchesSearch && matchesStatus && matchesPriority
  })

  const stats = {
    totalIssues: issues.length,
    reportedIssues: issues.filter(i => i.status === 'REPORTED').length,
    inProgressIssues: issues.filter(i => i.status === 'IN_PROGRESS').length,
    resolvedIssues: issues.filter(i => i.status === 'RESOLVED').length,
    totalUsers: users.length,
    totalDepartments: departments.length
  }

  // Show loading state
  if (loading) {
    return (
      <div className="min-h-screen bg-gray-50 flex items-center justify-center">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600 mx-auto mb-4"></div>
          <p className="text-gray-600">Loading admin dashboard...</p>
        </div>
      </div>
    )
  }

  const handleViewIssue = (issue: Issue) => {
    setSelectedIssue(issue)
    setIsDetailDialogOpen(true)
  }

  const handleEditIssue = (issue: Issue) => {
    setSelectedIssue(issue)
    setAssignedStaffId(issue.assignedTo?.id || "")
    setNewStatus(issue.status)
    setNewPriority(issue.priority)
    setNotes("")
    setIsEditDialogOpen(true)
  }

  const handleUpdateIssueStatus = async (issueId: string, status: string) => {
    try {
      setActionLoading(true)
      const response = await fetch(`/api/issues/${issueId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status }),
      })

      if (response.ok) {
        // Update local state
        setIssues(prevIssues => 
          prevIssues.map(issue => 
            issue.id === issueId 
              ? { ...issue, status, updatedAt: new Date().toISOString() }
              : issue
          )
        )
        
        // Show success feedback
        alert('Issue status updated successfully!')
      } else {
        throw new Error('Failed to update issue status')
      }
    } catch (error) {
      console.error('Error updating issue status:', error)
      alert('Failed to update issue status. Please try again.')
    } finally {
      setActionLoading(false)
    }
  }

  const handleAssignIssue = async (issueId: string, staffId: string) => {
    try {
      setActionLoading(true)
      const response = await fetch(`/api/issues/${issueId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ assignedToId: staffId }),
      })

      if (response.ok) {
        // Update local state
        const assignedStaff = users.find(u => u.id === staffId)
        setIssues(prevIssues => 
          prevIssues.map(issue => 
            issue.id === issueId 
              ? { ...issue, assignedTo: assignedStaff, updatedAt: new Date().toISOString() }
              : issue
          )
        )
        
        // Show success feedback
        alert('Issue assigned successfully!')
      } else {
        throw new Error('Failed to assign issue')
      }
    } catch (error) {
      console.error('Error assigning issue:', error)
      alert('Failed to assign issue. Please try again.')
    } finally {
      setActionLoading(false)
    }
  }

  const handleDeleteIssue = async (issueId: string) => {
    if (!confirm('Are you sure you want to delete this issue? This action cannot be undone.')) {
      return
    }

    try {
      setActionLoading(true)
      const response = await fetch(`/api/issues/${issueId}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        // Update local state
        setIssues(prevIssues => prevIssues.filter(issue => issue.id !== issueId))
        
        // Show success feedback
        alert('Issue deleted successfully!')
      } else {
        throw new Error('Failed to delete issue')
      }
    } catch (error) {
      console.error('Error deleting issue:', error)
      alert('Failed to delete issue. Please try again.')
    } finally {
      setActionLoading(false)
    }
  }

  const handleAddNotes = async (issueId: string, notes: string) => {
    try {
      setActionLoading(true)
      const response = await fetch(`/api/issues/${issueId}`, {
        method: 'PATCH',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ notes }),
      })

      if (response.ok) {
        // Update local state
        setIssues(prevIssues => 
          prevIssues.map(issue => 
            issue.id === issueId 
              ? { ...issue, updatedAt: new Date().toISOString() }
              : issue
          )
        )
        
        // Show success feedback
        alert('Notes added successfully!')
        setNotes("")
      } else {
        throw new Error('Failed to add notes')
      }
    } catch (error) {
      console.error('Error adding notes:', error)
      alert('Failed to add notes. Please try again.')
    } finally {
      setActionLoading(false)
    }
  }

  const handleBulkActions = async (action: string) => {
    if (selectedIssues.length === 0) {
      alert('Please select at least one issue to perform bulk actions.')
      return
    }

    try {
      setActionLoading(true)
      
      for (const issueId of selectedIssues) {
        let updateData = {}
        
        switch (action) {
          case 'resolve':
            updateData = { status: 'RESOLVED' }
            break
          case 'in_progress':
            updateData = { status: 'IN_PROGRESS' }
            break
          case 'reject':
            updateData = { status: 'REJECTED' }
            break
          case 'delete':
            await fetch(`/api/issues/${issueId}`, { method: 'DELETE' })
            continue
          default:
            break
        }

        if (Object.keys(updateData).length > 0) {
          await fetch(`/api/issues/${issueId}`, {
            method: 'PATCH',
            headers: {
              'Content-Type': 'application/json',
            },
            body: JSON.stringify(updateData),
          })
        }
      }

      // Refresh issues list
      const issuesResponse = await fetch('/api/issues')
      const issuesData = await issuesResponse.json()
      setIssues(issuesData.issues || [])
      
      // Clear selection
      setSelectedIssues([])
      
      // Show success feedback
      alert(`Bulk ${action} action completed successfully!`)
    } catch (error) {
      console.error('Error performing bulk action:', error)
      alert('Failed to perform bulk action. Please try again.')
    } finally {
      setActionLoading(false)
    }
  }

  const handleIssueSelection = (issueId: string, checked: boolean) => {
    setSelectedIssues(prev => 
      checked 
        ? [...prev, issueId]
        : prev.filter(id => id !== issueId)
    )
  }

  const handleSelectAll = (checked: boolean) => {
    setSelectedIssues(checked ? filteredIssues.map(issue => issue.id) : [])
  }

  // User management functions
  const handleCreateUser = async () => {
    if (!newUser.email || !newUser.password) {
      alert('Email and password are required')
      return
    }

    if (newUser.password !== newUser.confirmPassword) {
      alert('Passwords do not match')
      return
    }

    if (newUser.password.length < 6) {
      alert('Password must be at least 6 characters long')
      return
    }

    try {
      setActionLoading(true)
      const response = await fetch('/api/users', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({
          email: newUser.email,
          name: newUser.name,
          role: newUser.role,
          password: newUser.password
        }),
      })

      if (response.ok) {
        const createdUser = await response.json()
        
        // Update local state
        setUsers(prevUsers => [createdUser, ...prevUsers])
        
        // Reset form
        setNewUser({
          email: '',
          name: '',
          role: 'STAFF',
          password: '',
          confirmPassword: ''
        })
        
        setIsCreateUserDialogOpen(false)
        alert('User created successfully!')
      } else {
        const error = await response.json()
        throw new Error(error.error || 'Failed to create user')
      }
    } catch (error) {
      console.error('Error creating user:', error)
      alert(`Failed to create user: ${error.message}`)
    } finally {
      setActionLoading(false)
    }
  }

  const handleEditUser = (user: User) => {
    setSelectedUser(user)
    setEditUser({
      name: user.name || '',
      role: user.role,
      password: '',
      confirmPassword: ''
    })
    setIsEditUserDialogOpen(true)
  }

  const handleUpdateUser = async () => {
    if (!selectedUser) return

    if (editUser.password && editUser.password !== editUser.confirmPassword) {
      alert('Passwords do not match')
      return
    }

    if (editUser.password && editUser.password.length < 6) {
      alert('Password must be at least 6 characters long')
      return
    }

    try {
      setActionLoading(true)
      const updateData: any = {
        name: editUser.name,
        role: editUser.role
      }

      if (editUser.password) {
        updateData.password = editUser.password
      }

      const response = await fetch(`/api/users/${selectedUser.id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify(updateData),
      })

      if (response.ok) {
        const updatedUser = await response.json()
        
        // Update local state
        setUsers(prevUsers => 
          prevUsers.map(user => 
            user.id === selectedUser.id ? updatedUser : user
          )
        )
        
        setIsEditUserDialogOpen(false)
        setSelectedUser(null)
        alert('User updated successfully!')
      } else {
        const error = await response.json()
        throw new Error(error.error || 'Failed to update user')
      }
    } catch (error) {
      console.error('Error updating user:', error)
      alert(`Failed to update user: ${error.message}`)
    } finally {
      setActionLoading(false)
    }
  }

  const handleDeleteUser = async (userId: string) => {
    const user = users.find(u => u.id === userId)
    if (!user) return

    if (!confirm(`Are you sure you want to delete ${user.name || user.email}? This action cannot be undone.`)) {
      return
    }

    try {
      setActionLoading(true)
      const response = await fetch(`/api/users/${userId}`, {
        method: 'DELETE',
      })

      if (response.ok) {
        // Update local state
        setUsers(prevUsers => prevUsers.filter(user => user.id !== userId))
        
        alert('User deleted successfully!')
      } else {
        const error = await response.json()
        throw new Error(error.error || 'Failed to delete user')
      }
    } catch (error) {
      console.error('Error deleting user:', error)
      alert(`Failed to delete user: ${error.message}`)
    } finally {
      setActionLoading(false)
    }
  }

  return (
    <div className="min-h-screen bg-gray-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center">
              <h1 className="text-2xl font-bold text-gray-900">Admin Dashboard</h1>
              <span className="ml-2 text-sm text-gray-500">City Management System</span>
            </div>
            <div className="flex items-center gap-4">
              <Button variant="outline" size="sm">
                <Settings className="h-4 w-4 mr-2" />
                Settings
              </Button>
              <Button variant="outline" size="sm" onClick={onClose}>
                <LogOut className="h-4 w-4 mr-2" />
                Exit Admin
              </Button>
            </div>
          </div>
        </div>
      </header>

      {/* Main Content */}
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        {/* Stats Section */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-6 gap-6 mb-8">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Total Issues</CardTitle>
              <BarChart3 className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalIssues}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Reported</CardTitle>
              <AlertTriangle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.reportedIssues}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">In Progress</CardTitle>
              <Clock className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.inProgressIssues}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Resolved</CardTitle>
              <CheckCircle className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.resolvedIssues}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Users</CardTitle>
              <Users className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalUsers}</div>
            </CardContent>
          </Card>
          
          <Card>
            <CardHeader className="flex flex-row items-center justify-between space-y-0 pb-2">
              <CardTitle className="text-sm font-medium">Departments</CardTitle>
              <TrendingUp className="h-4 w-4 text-muted-foreground" />
            </CardHeader>
            <CardContent>
              <div className="text-2xl font-bold">{stats.totalDepartments}</div>
            </CardContent>
          </Card>
        </div>

        {/* Main Content Tabs */}
        <Tabs defaultValue="issues" className="space-y-6">
          <TabsList>
            <TabsTrigger value="issues">Issues</TabsTrigger>
            <TabsTrigger value="users">Users</TabsTrigger>
            <TabsTrigger value="departments">Departments</TabsTrigger>
            <TabsTrigger value="map">Map View</TabsTrigger>
            <TabsTrigger value="analytics">Analytics</TabsTrigger>
          </TabsList>

          <TabsContent value="issues" className="space-y-6">
            {/* Filters */}
            <Card>
              <CardHeader>
                <CardTitle>Issue Management</CardTitle>
                <CardDescription>Manage and track all reported issues</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="flex flex-col sm:flex-row gap-4 mb-6">
                  <div className="flex-1">
                    <div className="relative">
                      <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-gray-400" />
                      <Input
                        placeholder="Search issues..."
                        value={searchTerm}
                        onChange={(e) => setSearchTerm(e.target.value)}
                        className="pl-10"
                      />
                    </div>
                  </div>
                  <Select value={statusFilter} onValueChange={setStatusFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Filter by status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Statuses</SelectItem>
                      <SelectItem value="REPORTED">Reported</SelectItem>
                      <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                      <SelectItem value="RESOLVED">Resolved</SelectItem>
                      <SelectItem value="REJECTED">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                  <Select value={priorityFilter} onValueChange={setPriorityFilter}>
                    <SelectTrigger className="w-full sm:w-[180px]">
                      <SelectValue placeholder="Filter by priority" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Priorities</SelectItem>
                      <SelectItem value="LOW">Low</SelectItem>
                      <SelectItem value="MEDIUM">Medium</SelectItem>
                      <SelectItem value="HIGH">High</SelectItem>
                      <SelectItem value="URGENT">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                {/* Issues Table */}
                <div className="space-y-4">
                  {/* Bulk Actions */}
                  {selectedIssues.length > 0 && (
                    <Card className="p-4">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-4">
                          <span className="text-sm font-medium">
                            {selectedIssues.length} issue{selectedIssues.length !== 1 ? 's' : ''} selected
                          </span>
                          <div className="flex gap-2">
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleBulkActions('in_progress')}
                              disabled={actionLoading}
                            >
                              <Clock className="h-4 w-4 mr-2" />
                              Mark In Progress
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleBulkActions('resolve')}
                              disabled={actionLoading}
                            >
                              <CheckCircle className="h-4 w-4 mr-2" />
                              Mark Resolved
                            </Button>
                            <Button
                              variant="outline"
                              size="sm"
                              onClick={() => handleBulkActions('reject')}
                              disabled={actionLoading}
                            >
                              <XCircle className="h-4 w-4 mr-2" />
                              Mark Rejected
                            </Button>
                            <Button
                              variant="destructive"
                              size="sm"
                              onClick={() => handleBulkActions('delete')}
                              disabled={actionLoading}
                            >
                              <Trash2 className="h-4 w-4 mr-2" />
                              Delete Selected
                            </Button>
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="sm"
                          onClick={() => setSelectedIssues([])}
                        >
                          Clear Selection
                        </Button>
                      </div>
                    </Card>
                  )}
                  
                  <div className="rounded-md border">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead className="w-12">
                            <input
                              type="checkbox"
                              checked={selectedIssues.length === filteredIssues.length && filteredIssues.length > 0}
                              onChange={(e) => handleSelectAll(e.target.checked)}
                              className="rounded border-gray-300"
                            />
                          </TableHead>
                          <TableHead>Title</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Priority</TableHead>
                          <TableHead>Location</TableHead>
                          <TableHead>Reporter</TableHead>
                          <TableHead>Created</TableHead>
                          <TableHead className="text-right">Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {loading ? (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-8">
                              Loading issues...
                            </TableCell>
                          </TableRow>
                        ) : filteredIssues.length === 0 ? (
                          <TableRow>
                            <TableCell colSpan={8} className="text-center py-8">
                              No issues found
                            </TableCell>
                          </TableRow>
                        ) : (
                          filteredIssues.map((issue) => (
                            <TableRow key={issue.id}>
                              <TableCell>
                                <input
                                  type="checkbox"
                                  checked={selectedIssues.includes(issue.id)}
                                  onChange={(e) => handleIssueSelection(issue.id, e.target.checked)}
                                  className="rounded border-gray-300"
                                />
                              </TableCell>
                              <TableCell>
                                <div>
                                  <div className="font-medium">{issue.title}</div>
                                  <div className="text-sm text-gray-500 truncate max-w-xs">
                                    {issue.description}
                                  </div>
                                </div>
                              </TableCell>
                              <TableCell>
                                <Badge className={getStatusColor(issue.status)}>
                                  <div className="flex items-center gap-1">
                                    {getStatusIcon(issue.status)}
                                    <span className="capitalize">{issue.status.replace('_', ' ')}</span>
                                  </div>
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <Badge className={getPriorityColor(issue.priority)}>
                                  {issue.priority}
                                </Badge>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-1">
                                  <MapPin className="h-3 w-3 text-gray-400" />
                                  <span className="text-sm">{issue.location}</span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <div className="flex items-center gap-2">
                                  <Avatar className="h-6 w-6">
                                    <AvatarFallback>
                                      {issue.reporter.name?.charAt(0) || issue.reporter.email.charAt(0)}
                                    </AvatarFallback>
                                  </Avatar>
                                  <span className="text-sm">{issue.reporter.name || issue.reporter.email}</span>
                                </div>
                              </TableCell>
                              <TableCell>
                                <span className="text-sm">
                                  {new Date(issue.createdAt).toLocaleDateString()}
                                </span>
                              </TableCell>
                              <TableCell className="text-right">
                                <div className="flex justify-end gap-2">
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleViewIssue(issue)}
                                    title="View Details"
                                  >
                                    <Eye className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleEditIssue(issue)}
                                    title="Edit Issue"
                                  >
                                    <Edit className="h-4 w-4" />
                                  </Button>
                                  <Button
                                    variant="ghost"
                                    size="sm"
                                    onClick={() => handleDeleteIssue(issue.id)}
                                    title="Delete Issue"
                                    disabled={actionLoading}
                                  >
                                    <Trash2 className="h-4 w-4" />
                                  </Button>
                                  {/* Quick Status Actions */}
                                  <div className="flex gap-1">
                                    {issue.status === 'REPORTED' && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => handleUpdateIssueStatus(issue.id, 'IN_PROGRESS')}
                                        title="Mark In Progress"
                                        disabled={actionLoading}
                                      >
                                        <Clock className="h-4 w-4" />
                                      </Button>
                                    )}
                                    {issue.status === 'IN_PROGRESS' && (
                                      <Button
                                        variant="ghost"
                                        size="sm"
                                        onClick={() => handleUpdateIssueStatus(issue.id, 'RESOLVED')}
                                        title="Mark Resolved"
                                        disabled={actionLoading}
                                      >
                                        <CheckCircle className="h-4 w-4" />
                                      </Button>
                                    )}
                                  </div>
                                </div>
                              </TableCell>
                            </TableRow>
                          ))
                        )}
                      </TableBody>
                    </Table>
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="users" className="space-y-6">
            <Card>
              <CardHeader>
                <div className="flex justify-between items-center">
                  <div>
                    <CardTitle>User Management</CardTitle>
                    <CardDescription>Manage system users and their roles</CardDescription>
                  </div>
                  <Button onClick={() => setIsCreateUserDialogOpen(true)}>
                    <Users className="h-4 w-4 mr-2" />
                    Add User
                  </Button>
                </div>
              </CardHeader>
              <CardContent>
                <div className="rounded-md border">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>User</TableHead>
                        <TableHead>Email</TableHead>
                        <TableHead>Role</TableHead>
                        <TableHead>Joined</TableHead>
                        <TableHead className="text-right">Actions</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {users.map((user) => (
                        <TableRow key={user.id}>
                          <TableCell>
                            <div className="flex items-center gap-3">
                              <Avatar>
                                <AvatarFallback>
                                  {user.name?.charAt(0) || user.email.charAt(0)}
                                </AvatarFallback>
                              </Avatar>
                              <div>
                                <div className="font-medium">{user.name || 'N/A'}</div>
                              </div>
                            </div>
                          </TableCell>
                          <TableCell>{user.email}</TableCell>
                          <TableCell>
                            <Badge variant={user.role === 'ADMIN' ? 'default' : 'secondary'}>
                              {user.role}
                            </Badge>
                          </TableCell>
                          <TableCell>
                            {new Date(user.createdAt).toLocaleDateString()}
                          </TableCell>
                          <TableCell className="text-right">
                            <div className="flex justify-end gap-2">
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleEditUser(user)}
                                title="Edit User"
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                variant="ghost"
                                size="sm"
                                onClick={() => handleDeleteUser(user.id)}
                                title="Delete User"
                                disabled={actionLoading}
                              >
                                <Trash2 className="h-4 w-4" />
                              </Button>
                            </div>
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="departments" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Department Management</CardTitle>
                <CardDescription>Manage city departments and their responsibilities</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                  {departments.map((department) => (
                    <Card key={department.id}>
                      <CardHeader>
                        <CardTitle className="text-lg">{department.name}</CardTitle>
                        <CardDescription>{department.description}</CardDescription>
                      </CardHeader>
                      <CardContent>
                        <div className="space-y-2">
                          <div className="text-sm">
                            <span className="font-medium">Email:</span> {department.email}
                          </div>
                          <div className="flex justify-between items-center">
                            <span className="text-sm text-gray-500">
                              {issues.filter(i => i.department.id === department.id).length} issues
                            </span>
                            <Button variant="outline" size="sm">
                              Edit
                            </Button>
                          </div>
                        </div>
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="map" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Issues Map View</CardTitle>
                <CardDescription>Geographic visualization of all reported issues</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-4">
                  <div className="flex flex-wrap gap-2">
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-yellow-500 rounded-full"></div>
                      <span className="text-sm">Reported</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-blue-500 rounded-full"></div>
                      <span className="text-sm">In Progress</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                      <span className="text-sm">Resolved</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                      <span className="text-sm">Rejected</span>
                    </div>
                  </div>
                  
                  <div className="h-[600px] border rounded-lg overflow-hidden">
                    <MapComponent
                      latitude={40.7128}
                      longitude={-74.0060}
                      height="600px"
                      editable={false}
                    />
                  </div>
                  
                  <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
                    {issues.filter(issue => issue.latitude && issue.longitude).map((issue) => (
                      <Card key={issue.id} className="cursor-pointer hover:shadow-md transition-shadow">
                        <CardHeader className="pb-3">
                          <div className="flex items-center justify-between">
                            <CardTitle className="text-sm">{issue.title}</CardTitle>
                            <Badge className={`text-xs ${getStatusColor(issue.status)}`}>
                              {issue.status}
                            </Badge>
                          </div>
                          <CardDescription className="text-xs">
                            {issue.location}
                          </CardDescription>
                        </CardHeader>
                        <CardContent className="pt-0">
                          <div className="flex items-center justify-between text-xs text-gray-500">
                            <span>{issue.type.name}</span>
                            <span>{new Date(issue.createdAt).toLocaleDateString()}</span>
                          </div>
                        </CardContent>
                      </Card>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="analytics" className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Analytics Dashboard</CardTitle>
                <CardDescription>System performance and metrics</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Issues by Status</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span>Reported</span>
                          <span className="font-medium">{stats.reportedIssues}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>In Progress</span>
                          <span className="font-medium">{stats.inProgressIssues}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>Resolved</span>
                          <span className="font-medium">{stats.resolvedIssues}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                  
                  <Card>
                    <CardHeader>
                      <CardTitle className="text-lg">Issues by Priority</CardTitle>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-3">
                        <div className="flex justify-between items-center">
                          <span>Low</span>
                          <span className="font-medium">{issues.filter(i => i.priority === 'LOW').length}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>Medium</span>
                          <span className="font-medium">{issues.filter(i => i.priority === 'MEDIUM').length}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>High</span>
                          <span className="font-medium">{issues.filter(i => i.priority === 'HIGH').length}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span>Urgent</span>
                          <span className="font-medium">{issues.filter(i => i.priority === 'URGENT').length}</span>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </div>
              </CardContent>
            </Card>
          </TabsContent>
        </Tabs>
      </main>

      {/* Issue Detail Dialog */}
      <Dialog open={isDetailDialogOpen} onOpenChange={setIsDetailDialogOpen}>
        <DialogContent className="sm:max-w-[600px]">
          <DialogHeader>
            <DialogTitle>Issue Details</DialogTitle>
            <DialogDescription>
              View detailed information about this issue
            </DialogDescription>
          </DialogHeader>
          {selectedIssue && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Status</label>
                  <Badge className={getStatusColor(selectedIssue.status)}>
                    <div className="flex items-center gap-1">
                      {getStatusIcon(selectedIssue.status)}
                      <span className="capitalize">{selectedIssue.status.replace('_', ' ')}</span>
                    </div>
                  </Badge>
                </div>
                <div>
                  <label className="text-sm font-medium">Priority</label>
                  <Badge className={getPriorityColor(selectedIssue.priority)}>
                    {selectedIssue.priority}
                  </Badge>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium">Title</label>
                <p className="text-lg font-semibold">{selectedIssue.title}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium">Description</label>
                <p className="text-gray-600">{selectedIssue.description}</p>
              </div>
              
              <div>
                <label className="text-sm font-medium">Location</label>
                <p className="text-gray-600">{selectedIssue.location}</p>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Reporter</label>
                  <p className="text-gray-600">{selectedIssue.reporter.name || selectedIssue.reporter.email}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Department</label>
                  <p className="text-gray-600">{selectedIssue.department.name}</p>
                </div>
              </div>
              
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Created</label>
                  <p className="text-gray-600">{new Date(selectedIssue.createdAt).toLocaleDateString()}</p>
                </div>
                <div>
                  <label className="text-sm font-medium">Updated</label>
                  <p className="text-gray-600">{new Date(selectedIssue.updatedAt).toLocaleDateString()}</p>
                </div>
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsDetailDialogOpen(false)}>
                  Close
                </Button>
                <Button onClick={() => {
                  setIsDetailDialogOpen(false)
                  setIsEditDialogOpen(true)
                }}>
                  Edit Issue
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Edit Issue Dialog */}
      <Dialog open={isEditDialogOpen} onOpenChange={setIsEditDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit Issue</DialogTitle>
            <DialogDescription>
              Update issue status and assign to staff
            </DialogDescription>
          </DialogHeader>
          {selectedIssue && (
            <div className="space-y-4">
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <label className="text-sm font-medium">Status</label>
                  <Select value={newStatus} onValueChange={setNewStatus}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="REPORTED">Reported</SelectItem>
                      <SelectItem value="IN_PROGRESS">In Progress</SelectItem>
                      <SelectItem value="RESOLVED">Resolved</SelectItem>
                      <SelectItem value="REJECTED">Rejected</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div>
                  <label className="text-sm font-medium">Priority</label>
                  <Select value={newPriority} onValueChange={setNewPriority}>
                    <SelectTrigger>
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="LOW">Low</SelectItem>
                      <SelectItem value="MEDIUM">Medium</SelectItem>
                      <SelectItem value="HIGH">High</SelectItem>
                      <SelectItem value="URGENT">Urgent</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              
              <div>
                <label className="text-sm font-medium">Assign to Staff</label>
                <Select value={assignedStaffId} onValueChange={setAssignedStaffId}>
                  <SelectTrigger>
                    <SelectValue placeholder="Select staff member" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="">Unassigned</SelectItem>
                    {users.filter(u => u.role === 'STAFF').map((user) => (
                      <SelectItem key={user.id} value={user.id}>
                        {user.name || user.email}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium">Notes</label>
                <Textarea 
                  placeholder="Add notes about this issue..." 
                  value={notes}
                  onChange={(e) => setNotes(e.target.value)}
                />
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsEditDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={async () => {
                    if (newStatus !== selectedIssue.status) {
                      await handleUpdateIssueStatus(selectedIssue.id, newStatus)
                    }
                    if (assignedStaffId !== (selectedIssue.assignedTo?.id || "")) {
                      await handleAssignIssue(selectedIssue.id, assignedStaffId)
                    }
                    if (notes.trim()) {
                      await handleAddNotes(selectedIssue.id, notes.trim())
                    }
                    if (newPriority !== selectedIssue.priority) {
                      // Handle priority update
                      try {
                        const response = await fetch(`/api/issues/${selectedIssue.id}`, {
                          method: 'PATCH',
                          headers: {
                            'Content-Type': 'application/json',
                          },
                          body: JSON.stringify({ priority: newPriority }),
                        })
                        if (response.ok) {
                          setIssues(prevIssues => 
                            prevIssues.map(issue => 
                              issue.id === selectedIssue.id 
                                ? { ...issue, priority: newPriority, updatedAt: new Date().toISOString() }
                                : issue
                            )
                          )
                        }
                      } catch (error) {
                        console.error('Error updating priority:', error)
                      }
                    }
                    setIsEditDialogOpen(false)
                  }}
                  disabled={actionLoading}
                >
                  {actionLoading ? 'Saving...' : 'Save Changes'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>

      {/* Create User Dialog */}
      <Dialog open={isCreateUserDialogOpen} onOpenChange={setIsCreateUserDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Create New User</DialogTitle>
            <DialogDescription>
              Add a new admin or staff user to the system
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4">
            <div>
              <label className="text-sm font-medium">Email *</label>
              <Input
                type="email"
                placeholder="user@example.com"
                value={newUser.email}
                onChange={(e) => setNewUser({...newUser, email: e.target.value})}
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Full Name</label>
              <Input
                placeholder="John Doe"
                value={newUser.name}
                onChange={(e) => setNewUser({...newUser, name: e.target.value})}
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Role *</label>
              <Select value={newUser.role} onValueChange={(value) => setNewUser({...newUser, role: value})}>
                <SelectTrigger>
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="STAFF">Staff</SelectItem>
                  <SelectItem value="ADMIN">Admin</SelectItem>
                  <SelectItem value="CITIZEN">Citizen</SelectItem>
                </SelectContent>
              </Select>
            </div>
            
            <div>
              <label className="text-sm font-medium">Password *</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={newUser.password}
                onChange={(e) => setNewUser({...newUser, password: e.target.value})}
              />
            </div>
            
            <div>
              <label className="text-sm font-medium">Confirm Password *</label>
              <Input
                type="password"
                placeholder="••••••••"
                value={newUser.confirmPassword}
                onChange={(e) => setNewUser({...newUser, confirmPassword: e.target.value})}
              />
            </div>
            
            <div className="flex justify-end gap-2">
              <Button variant="outline" onClick={() => setIsCreateUserDialogOpen(false)}>
                Cancel
              </Button>
              <Button 
                onClick={handleCreateUser}
                disabled={actionLoading}
              >
                {actionLoading ? 'Creating...' : 'Create User'}
              </Button>
            </div>
          </div>
        </DialogContent>
      </Dialog>

      {/* Edit User Dialog */}
      <Dialog open={isEditUserDialogOpen} onOpenChange={setIsEditUserDialogOpen}>
        <DialogContent className="sm:max-w-[500px]">
          <DialogHeader>
            <DialogTitle>Edit User</DialogTitle>
            <DialogDescription>
              Update user information and role
            </DialogDescription>
          </DialogHeader>
          {selectedUser && (
            <div className="space-y-4">
              <div>
                <label className="text-sm font-medium">Email</label>
                <Input
                  type="email"
                  value={selectedUser.email}
                  disabled
                  className="bg-gray-50"
                />
                <p className="text-xs text-gray-500 mt-1">Email cannot be changed</p>
              </div>
              
              <div>
                <label className="text-sm font-medium">Full Name</label>
                <Input
                  placeholder="John Doe"
                  value={editUser.name}
                  onChange={(e) => setEditUser({...editUser, name: e.target.value})}
                />
              </div>
              
              <div>
                <label className="text-sm font-medium">Role</label>
                <Select value={editUser.role} onValueChange={(value) => setEditUser({...editUser, role: value})}>
                  <SelectTrigger>
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="CITIZEN">Citizen</SelectItem>
                    <SelectItem value="STAFF">Staff</SelectItem>
                    <SelectItem value="ADMIN">Admin</SelectItem>
                  </SelectContent>
                </Select>
              </div>
              
              <div>
                <label className="text-sm font-medium">New Password (leave blank to keep current)</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={editUser.password}
                  onChange={(e) => setEditUser({...editUser, password: e.target.value})}
                />
              </div>
              
              <div>
                <label className="text-sm font-medium">Confirm New Password</label>
                <Input
                  type="password"
                  placeholder="••••••••"
                  value={editUser.confirmPassword}
                  onChange={(e) => setEditUser({...editUser, confirmPassword: e.target.value})}
                />
              </div>
              
              <div className="flex justify-end gap-2">
                <Button variant="outline" onClick={() => setIsEditUserDialogOpen(false)}>
                  Cancel
                </Button>
                <Button 
                  onClick={handleUpdateUser}
                  disabled={actionLoading}
                >
                  {actionLoading ? 'Updating...' : 'Update User'}
                </Button>
              </div>
            </div>
          )}
        </DialogContent>
      </Dialog>
    </div>
  )
}