import { Card, CardContent } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { MapPin, AlertTriangle, CheckCircle, Clock, XCircle } from "lucide-react"

interface Issue {
  id: string
  title: string
  description: string
  location: string
  latitude?: number
  longitude?: number
  status: string
  priority: string
  type: string
  imageUrl?: string
  createdAt: string
}

interface IssueCardProps {
  issue: Issue
  onClick?: () => void
}

export default function IssueCard({ issue, onClick }: IssueCardProps) {
  const getStatusIcon = (status: string) => {
    switch (status) {
      case "REPORTED":
        return <AlertTriangle className="h-4 w-4" />
      case "IN_PROGRESS":
        return <Clock className="h-4 w-4" />
      case "RESOLVED":
        return <CheckCircle className="h-4 w-4" />
      case "REJECTED":
        return <XCircle className="h-4 w-4" />
      default:
        return <AlertTriangle className="h-4 w-4" />
    }
  }

  const getStatusColor = (status: string) => {
    switch (status) {
      case "REPORTED":
        return "bg-yellow-100 text-yellow-800"
      case "IN_PROGRESS":
        return "bg-blue-100 text-blue-800"
      case "RESOLVED":
        return "bg-green-100 text-green-800"
      case "REJECTED":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  const getPriorityColor = (priority: string) => {
    switch (priority) {
      case "LOW":
        return "bg-green-100 text-green-800"
      case "MEDIUM":
        return "bg-yellow-100 text-yellow-800"
      case "HIGH":
        return "bg-orange-100 text-orange-800"
      case "URGENT":
        return "bg-red-100 text-red-800"
      default:
        return "bg-gray-100 text-gray-800"
    }
  }

  return (
    <Card className="hover:shadow-md transition-shadow cursor-pointer" onClick={onClick}>
      <CardContent className="p-4">
        <div className="flex items-start justify-between">
          <div className="flex-1">
            <div className="flex items-center gap-2 mb-2">
              <h4 className="font-semibold text-gray-900">{issue.title}</h4>
              <Badge className={getStatusColor(issue.status)}>
                <div className="flex items-center gap-1">
                  {getStatusIcon(issue.status)}
                  <span className="capitalize">{issue.status.replace('_', ' ')}</span>
                </div>
              </Badge>
              <Badge className={getPriorityColor(issue.priority)}>
                {issue.priority}
              </Badge>
            </div>
            
            {issue.imageUrl && (
              <div className="mb-3">
                <img
                  src={issue.imageUrl}
                  alt={issue.title}
                  className="w-full h-48 object-cover rounded-md"
                  onError={(e) => {
                    // Fallback: hide image if it fails to load
                    const target = e.target as HTMLImageElement
                    target.style.display = 'none'
                  }}
                />
              </div>
            )}
            
            <p className="text-gray-600 mb-2">{issue.description}</p>
            
            <div className="flex items-center gap-4 text-sm text-gray-500">
              <div className="flex items-center gap-1">
                <MapPin className="h-4 w-4" />
                <span>{issue.location}</span>
              </div>
              {(issue.latitude && issue.longitude) && (
                <div className="flex items-center gap-1 text-xs">
                  <span className="font-medium">GPS:</span>
                  <span>{issue.latitude.toFixed(4)}, {issue.longitude.toFixed(4)}</span>
                </div>
              )}
              <div className="flex items-center gap-1">
                <span className="font-medium">Type:</span>
                <span>{issue.type}</span>
              </div>
              <div className="flex items-center gap-1">
                <span className="font-medium">Reported:</span>
                <span>{new Date(issue.createdAt).toLocaleDateString()}</span>
              </div>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}