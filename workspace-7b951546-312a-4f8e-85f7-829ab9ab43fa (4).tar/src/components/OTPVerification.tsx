"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Label } from "@/components/ui/label"
import { Dialog, DialogContent, DialogDescription, DialogHeader, DialogTitle } from "@/components/ui/dialog"
import { InputOTP, InputOTPGroup, InputOTPSlot } from "@/components/ui/input-otp"
import { AlertCircle, Mail, Shield, Clock, RefreshCw } from "lucide-react"

interface OTPVerificationProps {
  isOpen: boolean
  onClose: () => void
  email: string
  onVerified: () => void
  onBackToRegister?: () => void
}

export default function OTPVerification({ 
  isOpen, 
  onClose, 
  email, 
  onVerified, 
  onBackToRegister 
}: OTPVerificationProps) {
  const [otp, setOTP] = useState("")
  const [isLoading, setIsLoading] = useState(false)
  const [error, setError] = useState("")
  const [remainingTime, setRemainingTime] = useState(0)
  const [canResend, setCanResend] = useState(false)
  const [otpSent, setOTPSent] = useState(false)

  useEffect(() => {
    if (isOpen && email) {
      // Check if there's already an active OTP for this email
      checkOTPStatus()
    }
  }, [isOpen, email])

  const checkOTPStatus = async () => {
    try {
      const response = await fetch('/api/otp/status', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      })

      const data = await response.json()

      if (response.ok) {
        if (data.hasActiveOTP) {
          setOTPSent(true)
          const serverTimeSeconds = data.remainingTimeSeconds || 3 * 60
          setRemainingTime(serverTimeSeconds)
          setCanResend(false)
          setError('An OTP was already sent to this email. Please check your email or wait for it to expire.')
          
          // Debug logging for existing OTP
          console.log('OTP Debug - Existing OTP found:', {
            remainingTimeSeconds: data.remainingTimeSeconds,
            remainingTime: data.remainingTime,
            serverTimeSeconds,
            clientTime: new Date().toISOString()
          })
        } else {
          sendOTP()
        }
      } else {
        sendOTP()
      }
    } catch (error) {
      console.error('Error checking OTP status:', error)
      sendOTP()
    }
  }

  useEffect(() => {
    if (remainingTime > 0) {
      const timer = setTimeout(() => {
        const newTime = remainingTime - 1
        setRemainingTime(newTime)
        
        // Debug logging for timer countdown
        if (newTime <= 10 || newTime % 30 === 0) { // Log every 30 seconds and last 10 seconds
          console.log('OTP Debug - Timer countdown:', {
            remainingTime: newTime,
            formattedTime: formatTime(newTime),
            timestamp: new Date().toISOString()
          })
        }
      }, 1000)
      return () => clearTimeout(timer)
    } else {
      console.log('OTP Debug - Timer expired at:', new Date().toISOString())
      setCanResend(true)
    }
  }, [remainingTime])

  const sendOTP = async () => {
    setIsLoading(true)
    setError("")
    
    try {
      const response = await fetch('/api/otp/send', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email }),
      })

      const data = await response.json()

      if (response.ok) {
        setOTPSent(true)
        const serverTimeSeconds = data.remainingTimeSeconds || 3 * 60
        setRemainingTime(serverTimeSeconds)
        setCanResend(false)
        setError("") // Clear any previous errors
        
        // Debug logging for deployed environment
        console.log('OTP Debug - Server Response:', {
          remainingTimeSeconds: data.remainingTimeSeconds,
          remainingTime: data.remainingTime,
          serverTimeSeconds,
          clientTime: new Date().toISOString()
        })
        
        // For development, show OTP in console
        if (data.devOTP) {
          console.log('Development OTP:', data.devOTP)
        }
      } else {
        if (data.error === 'OTP already sent') {
          setError(data.message || 'OTP already sent')
          // If there's a retry time, update the remaining time
          if (data.remainingTimeSeconds) {
            setRemainingTime(data.remainingTimeSeconds)
            setCanResend(false)
            console.log('OTP Debug - Existing OTP remaining time:', data.remainingTimeSeconds, 'seconds')
          } else if (data.retryAfter) {
            setRemainingTime(data.retryAfter)
            setCanResend(false)
            console.log('OTP Debug - Existing OTP retry after:', data.retryAfter, 'seconds')
          }
        } else {
          setError(data.error || 'Failed to send OTP')
        }
      }
    } catch (error) {
      console.error('Error sending OTP:', error)
      setError('Failed to send OTP')
    } finally {
      setIsLoading(false)
    }
  }

  const verifyOTP = async () => {
    if (!otp || otp.length !== 6) {
      setError('Please enter a 6-digit OTP')
      return
    }

    setIsLoading(true)
    setError("")

    try {
      const response = await fetch('/api/otp/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ email, otp }),
      })

      const data = await response.json()

      if (response.ok) {
        onVerified()
        onClose()
      } else {
        if (data.error === 'Invalid or expired OTP') {
          setError('This OTP has expired or is invalid. Please request a new one.')
          setCanResend(true)
        } else if (data.error === 'Too many attempts') {
          setError('Too many failed attempts. Please request a new OTP.')
          setCanResend(true)
        } else {
          setError(data.error || 'Invalid OTP')
        }
      }
    } catch (error) {
      console.error('Error verifying OTP:', error)
      setError('Failed to verify OTP')
    } finally {
      setIsLoading(false)
    }
  }

  const handleResendOTP = () => {
    sendOTP()
  }

  const formatTime = (seconds: number) => {
    const mins = Math.floor(seconds / 60)
    const secs = seconds % 60
    return `${mins}:${secs.toString().padStart(2, '0')}`
  }

  const handleOTPChange = (value: string) => {
    // Only allow numbers
    const numericValue = value.replace(/[^0-9]/g, '')
    // Limit to 6 digits
    if (numericValue.length <= 6) {
      setOTP(numericValue)
      setError("")
    }
  }

  return (
    <Dialog open={isOpen} onOpenChange={onClose}>
      <DialogContent className="sm:max-w-[425px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Shield className="h-5 w-5" />
            Verify Your Email
          </DialogTitle>
          <DialogDescription>
            We've sent a 6-digit OTP to {email}. Please enter it below to verify your email address.
          </DialogDescription>
        </DialogHeader>
        
        <div className="space-y-6">
          {otpSent && (
            <div className="p-3 bg-green-50 border border-green-200 rounded-md">
              <p className="text-sm text-green-600 flex items-center gap-1">
                <Mail className="h-4 w-4" />
                OTP sent successfully! Check your email.
              </p>
            </div>
          )}
          
          <div className="space-y-2">
            <Label htmlFor="otp">Enter 6-digit OTP</Label>
            <div className="flex justify-center">
              <InputOTP
                id="otp"
                maxLength={6}
                value={otp}
                onChange={(value) => handleOTPChange(value)}
              >
                <InputOTPGroup>
                  <InputOTPSlot index={0} />
                  <InputOTPSlot index={1} />
                  <InputOTPSlot index={2} />
                  <InputOTPSlot index={3} />
                  <InputOTPSlot index={4} />
                  <InputOTPSlot index={5} />
                </InputOTPGroup>
              </InputOTP>
            </div>
            {error && (
              <p className="text-sm text-red-500 flex items-center gap-1 justify-center">
                <AlertCircle className="h-3 w-3" />
                {error}
              </p>
            )}
          </div>
          
          <div className="flex flex-col gap-3">
            <Button 
              onClick={verifyOTP} 
              disabled={isLoading || otp.length !== 6}
              className="w-full"
            >
              {isLoading ? "Verifying..." : "Verify OTP"}
            </Button>
            
            <div className="flex items-center justify-between text-sm">
              <div className="flex items-center gap-1 text-gray-500">
                <Clock className="h-4 w-4" />
                {canResend ? (
                  <span>OTP expired</span>
                ) : (
                  <span>Expires in {formatTime(remainingTime)}</span>
                )}
              </div>
              
              <Button
                variant="outline"
                size="sm"
                onClick={handleResendOTP}
                disabled={!canResend || isLoading}
                className="flex items-center gap-1"
              >
                <RefreshCw className="h-3 w-3" />
                Resend OTP
              </Button>
            </div>
          </div>
          
          {onBackToRegister && (
            <div className="pt-4 border-t">
              <Button
                variant="ghost"
                size="sm"
                onClick={onBackToRegister}
                className="w-full"
              >
                ← Back to Registration
              </Button>
            </div>
          )}
          
          {/* Development Note */}
          {process.env.NODE_ENV === 'development' && (
            <Card className="mt-4">
              <CardHeader className="pb-2">
                <CardTitle className="text-xs">Development Mode</CardTitle>
              </CardHeader>
              <CardContent className="pt-0">
                <p className="text-xs text-gray-600">
                  Check the browser console for the OTP code.
                </p>
              </CardContent>
            </Card>
          )}
        </div>
      </DialogContent>
    </Dialog>
  )
}