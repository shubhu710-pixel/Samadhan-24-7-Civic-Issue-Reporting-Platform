#!/usr/bin/env node

const https = require('https');

// Test OTP send function
function testOTPSend() {
  const data = JSON.stringify({
    email: 'test123@example.com'
  });

  const options = {
    hostname: 'p0sx6770v1u1-deploy.space.z.ai',
    port: 443,
    path: '/api/otp/send',
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'Content-Length': data.length
    }
  };

  const req = https.request(options, (res) => {
    console.log(`Status Code: ${res.statusCode}`);
    console.log(`Status Message: ${res.statusMessage}`);
    
    let responseData = '';
    
    res.on('data', (chunk) => {
      responseData += chunk;
    });
    
    res.on('end', () => {
      try {
        const parsedData = JSON.parse(responseData);
        console.log('Response:', JSON.stringify(parsedData, null, 2));
        
        if (parsedData.devOTP) {
          console.log(`\n🔐 YOUR OTP IS: ${parsedData.devOTP}`);
          console.log(`📧 Email: test123@example.com`);
        }
      } catch (e) {
        console.log('Raw Response:', responseData);
      }
    });
  });

  req.on('error', (error) => {
    console.error('Error:', error.message);
  });

  req.write(data);
  req.end();
}

testOTPSend();