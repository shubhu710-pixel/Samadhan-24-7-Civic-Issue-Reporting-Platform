#!/usr/bin/env node

// Script to check OTP status in deployed environment
const API_BASE = 'https://p0sx6770v1u1-deploy.space.z.ai';

async function checkOTPStatus(email) {
  try {
    const response = await fetch(`${API_BASE}/api/otp/status`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });

    const data = await response.json();
    console.log(`\n📧 OTP Status for: ${email}`);
    console.log('─'.repeat(50));
    console.log(`✅ Email Verified: ${data.emailVerified}`);
    console.log(`🔑 Has Active OTP: ${data.hasActiveOTP}`);
    
    if (data.hasActiveOTP) {
      console.log(`⏰ Remaining Time: ${data.remainingTime} minutes (${data.remainingTimeSeconds} seconds)`);
    }
    
    console.log(`💬 Message: ${data.message}`);
    console.log('─'.repeat(50));
    
    return data;
  } catch (error) {
    console.error('❌ Error checking OTP status:', error.message);
    return null;
  }
}

async function sendOTP(email) {
  try {
    console.log(`\n📤 Sending OTP to: ${email}`);
    console.log('─'.repeat(50));
    
    const response = await fetch(`${API_BASE}/api/otp/send`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email }),
    });

    const data = await response.json();
    
    if (data.devOTP) {
      console.log(`🔢 Development OTP: ${data.devOTP}`);
    }
    
    console.log(`✅ Message: ${data.message}`);
    console.log(`📧 Email Sent: ${data.emailSent}`);
    
    if (data.error) {
      console.log(`❌ Error: ${data.error}`);
    }
    
    console.log('─'.repeat(50));
    
    return data;
  } catch (error) {
    console.error('❌ Error sending OTP:', error.message);
    return null;
  }
}

async function verifyOTP(email, otp) {
  try {
    console.log(`\n🔍 Verifying OTP for: ${email}`);
    console.log(`🔢 OTP: ${otp}`);
    console.log('─'.repeat(50));
    
    const response = await fetch(`${API_BASE}/api/otp/verify`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email, otp }),
    });

    const data = await response.json();
    
    console.log(`✅ Message: ${data.message}`);
    console.log(`📧 Email Verified: ${data.emailVerified}`);
    console.log(`👤 User Exists: ${data.userExists}`);
    
    if (data.error) {
      console.log(`❌ Error: ${data.error}`);
      if (data.remainingAttempts !== undefined) {
        console.log(`🔄 Remaining Attempts: ${data.remainingAttempts}`);
      }
    }
    
    console.log('─'.repeat(50));
    
    return data;
  } catch (error) {
    console.error('❌ Error verifying OTP:', error.message);
    return null;
  }
}

async function listUsers() {
  try {
    console.log('\n👥 All Users in System');
    console.log('─'.repeat(50));
    
    const response = await fetch(`${API_BASE}/api/debug/users`);
    const data = await response.json();
    
    if (data.users) {
      data.users.forEach((user, index) => {
        console.log(`\n${index + 1}. 📧 ${user.email}`);
        console.log(`   👤 Name: ${user.name}`);
        console.log(`   🔑 Role: ${user.role}`);
        console.log(`   ✅ Verified: ${user.emailVerified}`);
        console.log(`   📅 Created: ${new Date(user.createdAt).toLocaleString()}`);
      });
    }
    
    console.log('\n─'.repeat(50));
    
    return data;
  } catch (error) {
    console.error('❌ Error listing users:', error.message);
    return null;
  }
}

// Main menu
async function main() {
  console.log('🔐 OTP Management Tool for Deployed Site');
  console.log('====================================');
  
  const args = process.argv.slice(2);
  
  if (args.length === 0) {
    console.log('\nUsage:');
    console.log('  node check-otp-deployed.js status <email>     - Check OTP status');
    console.log('  node check-otp-deployed.js send <email>       - Send OTP');
    console.log('  node check-otp-deployed.js verify <email> <otp> - Verify OTP');
    console.log('  node check-otp-deployed.js users             - List all users');
    console.log('\nExamples:');
    console.log('  node check-otp-deployed.js status test@example.com');
    console.log('  node check-otp-deployed.js send test@example.com');
    console.log('  node check-otp-deployed.js verify test@example.com 123456');
    console.log('  node check-otp-deployed.js users');
    return;
  }
  
  const command = args[0];
  
  switch (command) {
    case 'status':
      if (args[1]) {
        await checkOTPStatus(args[1]);
      } else {
        console.log('❌ Please provide an email address');
      }
      break;
      
    case 'send':
      if (args[1]) {
        await sendOTP(args[1]);
      } else {
        console.log('❌ Please provide an email address');
      }
      break;
      
    case 'verify':
      if (args[1] && args[2]) {
        await verifyOTP(args[1], args[2]);
      } else {
        console.log('❌ Please provide email and OTP');
      }
      break;
      
    case 'users':
      await listUsers();
      break;
      
    default:
      console.log('❌ Unknown command. Use "help" to see available commands.');
  }
}

main();