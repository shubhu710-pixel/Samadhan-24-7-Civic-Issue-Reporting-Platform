const { PrismaClient } = require('@prisma/client');
require('dotenv').config();

const prisma = new PrismaClient();

async function getOTP() {
  try {
    // Get all OTPs
    const otps = await prisma.oTP.findMany({
      include: {
        user: true
      },
      orderBy: {
        createdAt: 'desc'
      }
    });

    console.log('🔐 All OTPs in Database');
    console.log('═'.repeat(50));
    
    if (otps.length === 0) {
      console.log('❌ No OTPs found in database');
      return;
    }

    otps.forEach((otp, index) => {
      const now = new Date();
      const expiresAt = new Date(otp.expiresAt);
      const isValid = expiresAt > now;
      
      console.log(`${index + 1}. 📧 ${otp.user?.email || otp.email}`);
      console.log(`   🔑 OTP Code: ${otp.otp}`);
      console.log(`   ⏰ Expires: ${expiresAt.toLocaleString()}`);
      console.log(`   ✅ Valid: ${isValid ? 'Yes' : 'No'}`);
      console.log(`   📅 Created: ${new Date(otp.createdAt).toLocaleString()}`);
      console.log(`   🔄 Verified: ${otp.verified ? 'Yes' : 'No'}`);
      console.log(`   🔢 Attempts: ${otp.attempts}`);
      console.log('─'.repeat(30));
    });

  } catch (error) {
    console.error('❌ Error fetching OTPs:', error.message);
  } finally {
    await prisma.$disconnect();
  }
}

getOTP();