// Simple OTP Test Script
// Run this with: node test-otp.js

const testEmail = 'test@example.com';

async function testOTPEndpoints() {
  console.log('🧪 Testing OTP System...\n');
  
  // Test 1: Send OTP
  console.log('1. Testing OTP Send...');
  try {
    const sendResponse = await fetch('http://localhost:3000/api/otp/send', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: testEmail }),
    });
    
    const sendData = await sendResponse.json();
    console.log('Send Response:', sendData);
    
    if (sendResponse.ok) {
      console.log('✅ OTP sent successfully!');
      if (sendData.devOTP) {
        console.log('🔑 Development OTP:', sendData.devOTP);
      }
    } else {
      console.log('❌ Failed to send OTP:', sendData.error);
    }
  } catch (error) {
    console.log('❌ Error sending OTP:', error.message);
  }
  
  console.log('\n2. Testing OTP Status...');
  try {
    const statusResponse = await fetch('http://localhost:3000/api/otp/status', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ email: testEmail }),
    });
    
    const statusData = await statusResponse.json();
    console.log('Status Response:', statusData);
    
    if (statusResponse.ok) {
      console.log('✅ Status check successful!');
    } else {
      console.log('❌ Failed to check status:', statusData.error);
    }
  } catch (error) {
    console.log('❌ Error checking status:', error.message);
  }
  
  // Wait for user to get OTP from console
  console.log('\n⏳ Check the browser console for the OTP, then enter it below:');
  console.log('Or check the development server logs for: `OTP for test@example.com: XXXXXX`');
  
  // Simulate OTP verification (you'll need to get the actual OTP)
  setTimeout(async () => {
    console.log('\n3. Testing OTP Verification...');
    console.log('Note: You need to replace XXXXXX with the actual OTP from the console');
    
    // This is just a template - you'll need to replace the OTP
    const mockOTP = 'XXXXXX'; // Replace with actual OTP
    
    try {
      const verifyResponse = await fetch('http://localhost:3000/api/otp/verify', {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ 
          email: testEmail, 
          otp: mockOTP 
        }),
      });
      
      const verifyData = await verifyResponse.json();
      console.log('Verify Response:', verifyData);
      
      if (verifyResponse.ok) {
        console.log('✅ OTP verified successfully!');
      } else {
        console.log('❌ Failed to verify OTP:', verifyData.error);
      }
    } catch (error) {
      console.log('❌ Error verifying OTP:', error.message);
    }
  }, 5000);
}

// Run the test
testOTPEndpoints();