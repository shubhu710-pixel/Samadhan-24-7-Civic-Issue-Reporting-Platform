// Complete OTP Test Script
// This script will test the entire OTP flow
// Run with: node test-otp-complete.js

const testEmail = 'testuser@example.com';
const baseUrl = 'http://localhost:3000';

async function makeRequest(url, options = {}) {
  try {
    const response = await fetch(baseUrl + url, {
      headers: {
        'Content-Type': 'application/json',
        ...options.headers,
      },
      ...options,
    });
    
    const data = await response.json();
    return {
      ok: response.ok,
      status: response.status,
      data,
    };
  } catch (error) {
    return {
      ok: false,
      error: error.message,
    };
  }
}

async function testOTPFlow() {
  console.log('🧪 Complete OTP System Test\n');
  console.log('Testing with email:', testEmail);
  console.log('Base URL:', baseUrl);
  console.log('='.repeat(50));
  
  // Test 1: Check initial status
  console.log('\n1. Checking initial OTP status...');
  const statusResult = await makeRequest('/api/otp/status', {
    method: 'POST',
    body: JSON.stringify({ email: testEmail }),
  });
  
  if (statusResult.ok) {
    console.log('✅ Initial status:', statusResult.data);
  } else {
    console.log('❌ Status check failed:', statusResult.data);
  }
  
  // Test 2: Send OTP
  console.log('\n2. Sending OTP...');
  const sendResult = await makeRequest('/api/otp/send', {
    method: 'POST',
    body: JSON.stringify({ email: testEmail }),
  });
  
  if (sendResult.ok) {
    console.log('✅ OTP sent successfully!');
    console.log('📧 Response:', sendResult.data);
    
    if (sendResult.data.devOTP) {
      console.log('🔑 Development OTP (for testing):', sendResult.data.devOTP);
      console.log('⚠️  In production, this would only be sent via email');
    }
  } else {
    console.log('❌ Failed to send OTP:', sendResult.data);
    return;
  }
  
  // Test 3: Check status after sending
  console.log('\n3. Checking status after sending OTP...');
  const statusAfterSend = await makeRequest('/api/otp/status', {
    method: 'POST',
    body: JSON.stringify({ email: testEmail }),
  });
  
  if (statusAfterSend.ok) {
    console.log('✅ Status after send:', statusAfterSend.data);
  } else {
    console.log('❌ Status check failed:', statusAfterSend.data);
  }
  
  // Test 4: Try to verify with wrong OTP
  console.log('\n4. Testing verification with wrong OTP...');
  const wrongVerifyResult = await makeRequest('/api/otp/verify', {
    method: 'POST',
    body: JSON.stringify({ email: testEmail, otp: '000000' }),
  });
  
  if (wrongVerifyResult.ok) {
    console.log('❌ Unexpected success with wrong OTP');
  } else {
    console.log('✅ Correctly rejected wrong OTP:', wrongVerifyResult.data);
  }
  
  // Test 5: Verify with correct OTP (if we have it)
  if (sendResult.data.devOTP) {
    console.log('\n5. Testing verification with correct OTP...');
    const correctVerifyResult = await makeRequest('/api/otp/verify', {
      method: 'POST',
      body: JSON.stringify({ email: testEmail, otp: sendResult.data.devOTP }),
    });
    
    if (correctVerifyResult.ok) {
      console.log('✅ OTP verified successfully!');
      console.log('📧 Verification result:', correctVerifyResult.data);
    } else {
      console.log('❌ Failed to verify correct OTP:', correctVerifyResult.data);
    }
  } else {
    console.log('\n5. ⚠️  Skipping correct OTP test (no devOTP available)');
  }
  
  // Test 6: Check final status
  console.log('\n6. Checking final status...');
  const finalStatus = await makeRequest('/api/otp/status', {
    method: 'POST',
    body: JSON.stringify({ email: testEmail }),
  });
  
  if (finalStatus.ok) {
    console.log('✅ Final status:', finalStatus.data);
  } else {
    console.log('❌ Final status check failed:', finalStatus.data);
  }
  
  console.log('\n' + '='.repeat(50));
  console.log('🎉 OTP System Test Complete!');
  console.log('\n💡 Tips:');
  console.log('- In development, check the browser console for OTP codes');
  console.log('- In production, OTPs are only sent via email');
  console.log('- Rate limiting prevents spam (429 status)');
  console.log('- OTPs expire after 10 minutes');
  console.log('- Maximum 3 attempts per OTP');
}

// Run the test
testOTPFlow().catch(console.error);