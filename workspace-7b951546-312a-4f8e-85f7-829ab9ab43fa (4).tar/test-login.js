const crypto = require('crypto');

// Test the password hashing
const password = 'admin123';
const hash = crypto.createHash('sha256').update(password).digest('hex');
console.log('Password:', password);
console.log('Hash:', hash);

// Test the exact same logic as in the API
async function verifyPassword(password, hashedPassword) {
  const inputHash = crypto.createHash('sha256').update(password).digest('hex');
  return inputHash === hashedPassword;
}

// Test with the hash we found in the database
const dbHash = '240be518fabd2724ddb6f04eeb1da5967448d7e831c08c8fa822809f74c720a9';
const isValid = verifyPassword(password, dbHash);
console.log('Password verification:', isValid);